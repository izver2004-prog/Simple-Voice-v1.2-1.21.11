# Simple Voice (Fabric 1.21.11)

Нужен и на клиенте, и на сервере. Клавиша V — меню (Настройки / Голос / Звук).

## Сборка jar через GitHub (ничего ставить не нужно)
1. Создайте репозиторий на github.com и загрузите в него ВСЁ содержимое этой папки,
   включая скрытую папку `.github`.
2. Вкладка **Actions** → **build** → дождитесь зелёной галочки (2–4 мин).
3. Откройте запуск → внизу **Artifacts** → `simplevoice-jar`. Внутри jar мода.

`gradle-wrapper.jar` в репозиторий класть не обязательно: workflow сам его создаст.

## Сборка у себя
JDK 21, затем один раз:  `gradle wrapper --gradle-version 9.2.0`
После этого:  `./gradlew build`  (Windows: `gradlew.bat build`)
Результат: build/libs/simplevoice-1.0.0.jar

## Версии
Номера в gradle.properties сверьте с https://fabricmc.net/develop
(Yarn, Fabric Loader, Fabric API для 1.21.11).
