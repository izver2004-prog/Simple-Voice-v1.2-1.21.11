package ru.example.voice;

/** Эффекты голоса: тон (наклон спектра) и высота (pitch shift на линии задержки). */
final class Effects {
	private static final int SIZE = 16384, MASK = SIZE - 1, WIN = 1920; // окно 40 мс
	private final float[] buf = new float[SIZE];
	private int w;
	private float phase, lp;

	float process(float in, float pitch, float tone) {
		// тон: -1 = глуше (больше басов), +1 = ярче (больше верхов)
		lp += 0.1f * (in - lp);
		float x = lp * (1f - tone) + (in - lp) * (1f + tone);

		buf[w & MASK] = x;
		float y = x;
		if (Math.abs(pitch - 1f) > 0.01f) {
			phase += (1f - pitch) / WIN;
			phase -= (float) Math.floor(phase);
			float p2 = phase + 0.5f;
			if (p2 >= 1f) p2 -= 1f;
			y = tap(phase) * gain(phase) + tap(p2) * gain(p2);
		}
		w++;
		return y;
	}

	private float tap(float p) {
		float pos = w - p * WIN;
		int i = (int) Math.floor(pos);
		float fr = pos - i;
		return buf[i & MASK] * (1f - fr) + buf[(i + 1) & MASK] * fr;
	}

	private static float gain(float p) {
		double s = Math.sin(Math.PI * p);
		return (float) (s * s);
	}
}
