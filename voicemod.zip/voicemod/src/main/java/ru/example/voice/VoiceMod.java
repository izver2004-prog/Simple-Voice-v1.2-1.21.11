package ru.example.voice;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.network.ServerPlayerEntity;

public class VoiceMod implements ModInitializer {
	public static final String MOD_ID = "simplevoice";
	/** Дальность слышимости в блоках. */
	public static final double RANGE = 48.0;

	@Override
	public void onInitialize() {
		PayloadTypeRegistry.playC2S().register(MicPacket.ID, MicPacket.CODEC);
		PayloadTypeRegistry.playS2C().register(SoundPacket.ID, SoundPacket.CODEC);

		// Выполняется в главном потоке сервера
		ServerPlayNetworking.registerGlobalReceiver(MicPacket.ID, (payload, ctx) -> {
			ServerPlayerEntity sender = ctx.player();
			if (payload.data().length > 1275) return; // макс. размер Opus-кадра

			for (ServerPlayerEntity p : ctx.server().getPlayerManager().getPlayerList()) {
				if (p == sender || p.getEntityWorld() != sender.getEntityWorld()) continue;
				double d2 = p.squaredDistanceTo(sender);
				if (d2 > RANGE * RANGE) continue;
				if (!ServerPlayNetworking.canSend(p, SoundPacket.ID)) continue; // у игрока нет мода

				float vol = (float) (1.0 - Math.sqrt(d2) / RANGE);
				ServerPlayNetworking.send(p, new SoundPacket(sender.getUuid(), vol, payload.data()));
			}
		});
	}
}
