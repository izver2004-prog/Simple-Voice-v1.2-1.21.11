package ru.example.voice;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;

/** Настройки клиента, хранятся в config/simplevoice.json. */
public final class VoiceConfig {
	public enum Mode { PTT, VOICE, ALWAYS }

	// --- общие ---
	public Mode mode = Mode.PTT;
	public int pttKey = GLFW.GLFW_KEY_B;
	public boolean micMuted = false;
	public boolean deafened = false;
	public boolean showHud = true;
	public String inputDevice = "";
	public String outputDevice = "";
	public transient boolean loopback = false; // тест микрофона, не сохраняется

	// --- голос ---
	public float micVolume = 1f;     // 0..2
	public float pitch = 1f;         // 0.5..2
	public float tone = 0f;          // -1..1
	public float threshold = 0.25f;  // 0..1, порог активации голосом
	public int holdMs = 400;         // сколько держать микрофон после речи
	public int bitrateKbps = 24;     // 8..64

	// --- звук ---
	public float masterVolume = 1f;  // 0..2
	public Set<String> mutedPlayers = new HashSet<>();
	public Map<String, Float> playerVolumes = new HashMap<>();

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static VoiceConfig instance;

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("simplevoice.json");
	}

	public static synchronized VoiceConfig get() {
		if (instance == null) {
			try {
				Path f = file();
				if (Files.exists(f)) instance = GSON.fromJson(Files.readString(f), VoiceConfig.class);
			} catch (Exception ignored) {}
			if (instance == null) instance = new VoiceConfig();
			if (instance.mode == null) instance.mode = Mode.PTT;
			if (instance.mutedPlayers == null) instance.mutedPlayers = new HashSet<>();
			if (instance.playerVolumes == null) instance.playerVolumes = new HashMap<>();
			if (instance.inputDevice == null) instance.inputDevice = "";
			if (instance.outputDevice == null) instance.outputDevice = "";
		}
		return instance;
	}

	public static void save() {
		try {
			Files.writeString(file(), GSON.toJson(get()));
		} catch (Exception ignored) {}
	}

	public void resetVoice() {
		micVolume = 1f; pitch = 1f; tone = 0f; threshold = 0.25f; holdMs = 400; bitrateKbps = 24;
	}
}
