package ru.example.voice;

import java.util.Arrays;
import java.util.UUID;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.TargetDataLine;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.concentus.OpusApplication;
import org.concentus.OpusEncoder;
import org.lwjgl.glfw.GLFW;

public class VoiceClient implements ClientModInitializer {
	public static final AudioFormat FORMAT = new AudioFormat(48000f, 16, 1, true, false);
	public static final int FRAME = 960; // 20 мс при 48 кГц

	static KeyBinding menuKey;
	static volatile boolean pttHeld;
	static volatile boolean transmitting;
	static volatile float level; // текущий уровень микрофона для индикатора (0..1)

	@Override
	public void onInitializeClient() {
		VoiceConfig.get();

		menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.simplevoice.menu",
				InputUtil.Type.KEYSYM,
				GLFW.GLFW_KEY_V,
				KeyBinding.Category.create(Identifier.of(VoiceMod.MOD_ID, "main"))));

		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			while (menuKey.wasPressed()) {
				if (mc.currentScreen == null) mc.setScreen(new VoiceScreen());
			}
			VoiceConfig c = VoiceConfig.get();
			pttHeld = mc.currentScreen == null && c.pttKey > 0
					&& GLFW.glfwGetKey(mc.getWindow().getHandle(), c.pttKey) == GLFW.GLFW_PRESS;
		});

		ClientPlayNetworking.registerGlobalReceiver(SoundPacket.ID, (p, ctx) -> Playback.push(p));
		HudRenderCallback.EVENT.register((ctx, tick) -> {
			MinecraftClient mc = MinecraftClient.getInstance();
			VoiceConfig c = VoiceConfig.get();
			if (!c.showHud || mc.options.hudHidden || mc.player == null) return;
			TextRenderer tr = mc.textRenderer;
			int y = 6;
			if (c.deafened) {
				ctx.drawTextWithShadow(tr, "Звук выключен", 6, y, 0xFFFF5555);
				y += 11;
			} else if (c.micMuted) {
				ctx.drawTextWithShadow(tr, "Микрофон выключен", 6, y, 0xFFFF5555);
				y += 11;
			} else if (transmitting) {
				ctx.drawTextWithShadow(tr, "● Вы говорите", 6, y, 0xFF55FF55);
				y += 11;
			}
			long now = System.currentTimeMillis();
			for (var e : Playback.LAST.entrySet()) {
				if (e.getKey().equals(Playback.LOCAL) || now - e.getValue() > 400) continue;
				ctx.drawTextWithShadow(tr, "♪ " + nameOf(e.getKey()), 6, y, 0xFFFFFFFF);
				y += 11;
			}
		});

		Thread t = new Thread(VoiceClient::captureLoop, "voice-capture");
		t.setDaemon(true);
		t.start();
	}

	static String nameOf(UUID id) {
		var h = MinecraftClient.getInstance().getNetworkHandler();
		PlayerListEntry e = h == null ? null : h.getPlayerListEntry(id);
		return e == null ? "?" : e.getProfile().name();
	}

	/** Шкала индикатора: 0..1, одинаковая для порога и для полоски. */
	static float toMeter(float rms) {
		return Math.min(1f, (float) Math.sqrt(rms) * 1.5f);
	}

	private static void captureLoop() {
		while (true) {
			String dev = VoiceConfig.get().inputDevice;
			try (TargetDataLine mic = AudioDevices.openIn(dev)) {
				OpusEncoder enc = new OpusEncoder(48000, 1, OpusApplication.OPUS_APPLICATION_VOIP);
				mic.open(FORMAT);
				mic.start();

				Effects fx = new Effects();
				byte[] raw = new byte[FRAME * 2];
				float[] f = new float[FRAME];
				short[] pcm = new short[FRAME];
				byte[] out = new byte[1275];
				int bitrate = -1;
				long lastLoud = 0;

				while (dev.equals(VoiceConfig.get().inputDevice)) {
					int read = 0;
					while (read < raw.length) {
						int n = mic.read(raw, read, raw.length - read);
						if (n <= 0) throw new IllegalStateException("mic closed");
						read += n;
					}
					VoiceConfig c = VoiceConfig.get();

					double sum = 0;
					for (int i = 0; i < FRAME; i++) {
						short s = (short) ((raw[i * 2] & 0xFF) | (raw[i * 2 + 1] << 8));
						float v = s / 32768f * c.micVolume;
						f[i] = v;
						sum += v * v;
					}
					float meter = toMeter((float) Math.sqrt(sum / FRAME));
					level = meter;

					long now = System.currentTimeMillis();
					boolean active;
					if (c.mode == VoiceConfig.Mode.ALWAYS) {
						active = true;
					} else if (c.mode == VoiceConfig.Mode.PTT) {
						active = pttHeld;
					} else {
						if (meter > c.threshold) lastLoud = now;
						active = now - lastLoud < c.holdMs;
					}
					if (c.micMuted) active = false;
					transmitting = active;
					if (!active) continue;

					for (int i = 0; i < FRAME; i++) {
						float y = fx.process(f[i], c.pitch, c.tone);
						pcm[i] = (short) Math.max(-32768, Math.min(32767, Math.round(y * 32767f)));
					}
					if (bitrate != c.bitrateKbps) {
						bitrate = c.bitrateKbps;
						enc.setBitrate(bitrate * 1000);
					}
					int len = enc.encode(pcm, 0, FRAME, out, 0, out.length);
					byte[] frame = Arrays.copyOf(out, len);

					if (c.loopback) Playback.push(new SoundPacket(Playback.LOCAL, 1f, frame));
					MinecraftClient.getInstance().execute(() -> {
						if (ClientPlayNetworking.canSend(MicPacket.ID)) {
							ClientPlayNetworking.send(new MicPacket(frame));
						}
					});
				}
			} catch (Exception e) {
				transmitting = false;
				try { Thread.sleep(3000); } catch (InterruptedException ie) { return; }
			}
		}
	}
}
