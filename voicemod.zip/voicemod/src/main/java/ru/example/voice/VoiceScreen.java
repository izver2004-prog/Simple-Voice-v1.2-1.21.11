package ru.example.voice;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.tooltip.Tooltip;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.input.KeyInput;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

/** Меню голосового чата: Настройки / Голос / Звук. */
public class VoiceScreen extends Screen {
	private enum Tab {
		SETTINGS("Настройки"), VOICE("Голос"), SOUND("Звук");
		final String title;
		Tab(String t) { title = t; }
	}

	private static final int W = 200, H = 20, STEP = 22, TOP = 48, PER_PAGE = 4;
	private static Tab tab = Tab.SETTINGS;
	private static int page = 0;

	private final VoiceConfig cfg = VoiceConfig.get();
	private boolean capturingKey;
	private int rowY;
	private int micX, micY;

	public VoiceScreen() {
		super(Text.literal("Голосовой чат"));
	}

	// ---------- построение ----------

	@Override
	protected void init() {
		int cx = width / 2;
		Tab[] tabs = Tab.values();
		for (int i = 0; i < tabs.length; i++) {
			Tab t = tabs[i];
			ButtonWidget b = ButtonWidget.builder(Text.literal(t.title), btn -> {
				tab = t;
				capturingKey = false;
				clearAndInit();
			}).dimensions(cx - 149 + i * 100, 20, 98, H).build();
			b.active = tab != t;
			addDrawableChild(b);
		}

		rowY = TOP;
		switch (tab) {
			case SETTINGS -> initSettings(cx - W / 2);
			case VOICE -> initVoice(cx - W / 2);
			case SOUND -> initSound(cx - W / 2);
		}

		addDrawableChild(ButtonWidget.builder(Text.literal("Готово"), b -> close())
				.dimensions(cx - 50, height - 26, 100, H).build());
	}

	private void button(int x, Text label, ButtonWidget.PressAction a) {
		addDrawableChild(ButtonWidget.builder(label, a).dimensions(x, rowY, W, H).build());
		rowY += STEP;
	}

	private void slider(int x, double min, double max, double cur,
						DoubleFunction<Text> label, DoubleConsumer set) {
		addDrawableChild(new Slider(x, rowY, W, H, min, max, cur, label, set));
		rowY += STEP;
	}

	// ---------- вкладка «Настройки» ----------

	private void initSettings(int x) {
		button(x, Text.literal("Активация: " + modeName(cfg.mode)), b -> {
			cfg.mode = VoiceConfig.Mode.values()[(cfg.mode.ordinal() + 1) % VoiceConfig.Mode.values().length];
			clearAndInit();
		});

		button(x, Text.literal(capturingKey
				? "Нажмите кнопку... (Esc — отмена)"
				: "Кнопка разговора: " + keyName(cfg.pttKey)), b -> {
			capturingKey = true;
			clearAndInit();
		});

		button(x, Text.literal("Микрофон: " + shortName(cfg.inputDevice)), b -> {
			cfg.inputDevice = cycle(AudioDevices.names(TargetDataLine.class), cfg.inputDevice);
			clearAndInit();
		});

		button(x, Text.literal("Вывод: " + shortName(cfg.outputDevice)), b -> {
			cfg.outputDevice = cycle(AudioDevices.names(SourceDataLine.class), cfg.outputDevice);
			Playback.reset();
			clearAndInit();
		});

		button(x, onOff("Микрофон выключен", cfg.micMuted), b -> {
			cfg.micMuted = !cfg.micMuted;
			clearAndInit();
		});

		button(x, onOff("Показывать индикатор говорящих", cfg.showHud), b -> {
			cfg.showHud = !cfg.showHud;
			clearAndInit();
		});

		// «Слышать себя» + справа кнопка-микрофон (без ВКЛ/ВЫКЛ, рисуется иконкой)
		addDrawableChild(ButtonWidget.builder(onOff("Тест: слышать себя", cfg.loopback), b -> {
			cfg.loopback = !cfg.loopback;
			clearAndInit();
		}).dimensions(x, rowY, W - 24, H).build());
		micX = x + W - 20;
		micY = rowY;
		ButtonWidget mic = ButtonWidget.builder(Text.empty(), b -> VoiceClient.menuMic = !VoiceClient.menuMic)
				.dimensions(micX, micY, 20, H).build();
		mic.setTooltip(Tooltip.of(Text.literal("Говорить и слышать себя, не выходя из меню (лучше в наушниках)")));
		addDrawableChild(mic);
		rowY += STEP;
	}

	// ---------- вкладка «Голос» ----------

	private void initVoice(int x) {
		slider(x, 0, 2, cfg.micVolume,
				v -> Text.literal("Громкость микрофона: " + Math.round(v * 100) + "%"),
				v -> cfg.micVolume = (float) v);

		slider(x, 0.5, 2.0, cfg.pitch,
				v -> Text.literal(String.format(Locale.ROOT, "Высота голоса: ×%.2f", v)),
				v -> cfg.pitch = (float) v);

		slider(x, -1, 1, cfg.tone,
				v -> Text.literal("Тон: " + (v < -0.05 ? "глухой" : v > 0.05 ? "яркий" : "нейтральный")
						+ " (" + Math.round(v * 100) + ")"),
				v -> cfg.tone = (float) v);

		slider(x, 0, 1, cfg.threshold,
				v -> Text.literal("Порог голосовой активации: " + Math.round(v * 100) + "%"),
				v -> cfg.threshold = (float) v);

		slider(x, 100, 1500, cfg.holdMs,
				v -> Text.literal("Удержание после речи: " + (Math.round(v / 50) * 50) + " мс"),
				v -> cfg.holdMs = (int) (Math.round(v / 50) * 50));

		slider(x, 8, 64, cfg.bitrateKbps,
				v -> Text.literal("Качество (битрейт): " + Math.round(v) + " кбит/с"),
				v -> cfg.bitrateKbps = (int) Math.round(v));

		rowY += 14; // место под индикатор уровня (рисуется в render)
		button(x, Text.literal("Сбросить настройки голоса"), b -> {
			cfg.resetVoice();
			clearAndInit();
		});
	}

	// ---------- вкладка «Звук» ----------

	private void initSound(int x) {
		slider(x, 0, 2, cfg.masterVolume,
				v -> Text.literal("Общая громкость игроков: " + Math.round(v * 100) + "%"),
				v -> cfg.masterVolume = (float) v);

		button(x, onOff("Отключить звук (не слышать никого)", cfg.deafened), b -> {
			cfg.deafened = !cfg.deafened;
			clearAndInit();
		});

		rowY += 12; // заголовок «Игроки»
		List<PlayerListEntry> list = otherPlayers();
		int pages = Math.max(1, (list.size() + PER_PAGE - 1) / PER_PAGE);
		page = Math.max(0, Math.min(page, pages - 1));

		for (int i = page * PER_PAGE; i < Math.min(list.size(), (page + 1) * PER_PAGE); i++) {
			UUID id = list.get(i).getProfile().id();
			String name = list.get(i).getProfile().name();
			String key = id.toString();
			float vol = cfg.playerVolumes.getOrDefault(key, 1f);
			boolean muted = cfg.mutedPlayers.contains(key);

			addDrawableChild(new Slider(x, rowY, 132, H, 0, 2, vol,
					v -> Text.literal(name + " " + Math.round(v * 100) + "%"),
					v -> cfg.playerVolumes.put(key, (float) v)));
			addDrawableChild(ButtonWidget.builder(
					muted ? Text.literal("Мут").formatted(Formatting.RED) : Text.literal("Звук"),
					b -> {
						if (!cfg.mutedPlayers.remove(key)) cfg.mutedPlayers.add(key);
						clearAndInit();
					}).dimensions(x + 136, rowY, 64, H).build());
			rowY += STEP;
		}

		if (pages > 1) {
			int cx = width / 2;
			ButtonWidget prev = ButtonWidget.builder(Text.literal("<"), b -> { page--; clearAndInit(); })
					.dimensions(cx - 60, rowY, 30, H).build();
			prev.active = page > 0;
			ButtonWidget next = ButtonWidget.builder(Text.literal(">"), b -> { page++; clearAndInit(); })
					.dimensions(cx + 30, rowY, 30, H).build();
			next.active = page < pages - 1;
			addDrawableChild(prev);
			addDrawableChild(next);
		}
	}

	private List<PlayerListEntry> otherPlayers() {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.getNetworkHandler() == null || mc.player == null) return List.of();
		UUID self = mc.player.getUuid();
		return mc.getNetworkHandler().getPlayerList().stream()
				.filter(e -> !e.getProfile().id().equals(self))
				.sorted(Comparator.comparing(e -> e.getProfile().name().toLowerCase(Locale.ROOT)))
				.toList();
	}

	// ---------- отрисовка и ввод ----------

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		super.render(ctx, mouseX, mouseY, delta);
		int cx = width / 2;
		ctx.drawCenteredTextWithShadow(textRenderer, title, cx, 7, 0xFFFFFFFF);

		if (tab == Tab.SETTINGS) {
			String hint = "Это меню открывается клавишей V (меняется в Управлении)";
			ctx.drawCenteredTextWithShadow(textRenderer, hint, cx, TOP + 7 * STEP + 4, 0xFFAAAAAA);
			drawMicIcon(ctx, micX + 10, micY + 10, VoiceClient.menuMic);
		} else if (tab == Tab.VOICE) {
			int x = cx - W / 2, y = TOP + 6 * STEP + 3;
			ctx.fill(x, y, x + W, y + 8, 0xFF303030);
			int fill = (int) (W * VoiceClient.level);
			boolean over = VoiceClient.level > cfg.threshold;
			ctx.fill(x, y, x + fill, y + 8, over ? 0xFF55FF55 : 0xFF8899AA);
			int tx = x + (int) (W * cfg.threshold);
			ctx.fill(tx, y - 2, tx + 1, y + 10, 0xFFFFFFFF); // отметка порога
		} else {
			ctx.drawCenteredTextWithShadow(textRenderer,
					Text.literal("Игроки на сервере (" + otherPlayers().size() + ")"),
					cx, TOP + 2 * STEP + 2, 0xFFFFFFFF);
		}
	}

	@Override
	public boolean keyPressed(KeyInput input) {
		if (capturingKey) {
			if (input.key() != GLFW.GLFW_KEY_ESCAPE) cfg.pttKey = input.key();
			capturingKey = false;
			clearAndInit();
			return true;
		}
		return super.keyPressed(input);
	}

	@Override
	public void removed() {
		VoiceClient.menuMic = false; // микрофон меню выключается при закрытии
		VoiceConfig.save();
	}

	/** Иконка микрофона: перечёркнутая, когда выключен. */
	private static void drawMicIcon(DrawContext ctx, int cx, int cy, boolean on) {
		int c = on ? 0xFF55FF55 : 0xFFAAAAAA;
		ctx.fill(cx - 2, cy - 6, cx + 2, cy + 1, c);          // капсула
		ctx.fill(cx - 4, cy - 2, cx - 3, cy + 3, c);          // дужка слева
		ctx.fill(cx + 3, cy - 2, cx + 4, cy + 3, c);          // дужка справа
		ctx.fill(cx - 3, cy + 3, cx + 3, cy + 4, c);          // низ дужки
		ctx.fill(cx - 1, cy + 4, cx + 1, cy + 6, c);          // ножка
		ctx.fill(cx - 3, cy + 6, cx + 3, cy + 7, c);          // подставка
		if (!on) {
			for (int t = 0; t <= 14; t++) {                    // красная перечёркивающая линия
				int x = cx - 6 + t * 12 / 14;
				int y = cy + 7 - t;
				ctx.fill(x, y, x + 2, y + 1, 0xFFFF5555);
			}
		}
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	// ---------- утилиты ----------

	private static String modeName(VoiceConfig.Mode m) {
		return switch (m) {
			case PTT -> "по зажатию кнопки";
			case VOICE -> "по голосу";
			case ALWAYS -> "всегда включён";
		};
	}

	private static Text onOff(String label, boolean on) {
		return Text.literal(label + ": " + (on ? "ВКЛ" : "ВЫКЛ"));
	}

	private static String shortName(String s) {
		if (s == null || s.isEmpty()) return "по умолчанию";
		return s.length() > 24 ? s.substring(0, 23) + "…" : s;
	}

	private static String cycle(List<String> names, String cur) {
		int i = names.indexOf(cur);
		return names.get((i + 1) % names.size());
	}

	static String keyName(int k) {
		return switch (k) {
			case GLFW.GLFW_KEY_SPACE -> "Пробел";
			case GLFW.GLFW_KEY_LEFT_SHIFT -> "Левый Shift";
			case GLFW.GLFW_KEY_RIGHT_SHIFT -> "Правый Shift";
			case GLFW.GLFW_KEY_LEFT_CONTROL -> "Левый Ctrl";
			case GLFW.GLFW_KEY_RIGHT_CONTROL -> "Правый Ctrl";
			case GLFW.GLFW_KEY_LEFT_ALT -> "Левый Alt";
			case GLFW.GLFW_KEY_RIGHT_ALT -> "Правый Alt";
			case GLFW.GLFW_KEY_TAB -> "Tab";
			case GLFW.GLFW_KEY_CAPS_LOCK -> "Caps Lock";
			case GLFW.GLFW_KEY_ENTER -> "Enter";
			case GLFW.GLFW_KEY_BACKSPACE -> "Backspace";
			case GLFW.GLFW_KEY_UP -> "Стрелка вверх";
			case GLFW.GLFW_KEY_DOWN -> "Стрелка вниз";
			case GLFW.GLFW_KEY_LEFT -> "Стрелка влево";
			case GLFW.GLFW_KEY_RIGHT -> "Стрелка вправо";
			default -> {
				if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F25) yield "F" + (k - GLFW.GLFW_KEY_F1 + 1);
				String n = GLFW.glfwGetKeyName(k, 0);
				yield n != null ? n.toUpperCase(Locale.ROOT) : "Клавиша " + k;
			}
		};
	}

	/** Слайдер с произвольным диапазоном и подписью. */
	private static final class Slider extends SliderWidget {
		private final double min, max;
		private final DoubleFunction<Text> label;
		private final DoubleConsumer setter;

		Slider(int x, int y, int w, int h, double min, double max, double cur,
			   DoubleFunction<Text> label, DoubleConsumer setter) {
			super(x, y, w, h, Text.empty(), Math.max(0, Math.min(1, (cur - min) / (max - min))));
			this.min = min;
			this.max = max;
			this.label = label;
			this.setter = setter;
			updateMessage();
		}

		@Override
		protected void updateMessage() {
			setMessage(label.apply(min + value * (max - min)));
		}

		@Override
		protected void applyValue() {
			setter.accept(min + value * (max - min));
		}
	}
}
