package ru.example.voice;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.sound.sampled.SourceDataLine;
import org.concentus.OpusDecoder;

/** Воспроизведение: у каждого говорящего свой декодер и своя линия вывода. */
final class Playback {
	static final UUID LOCAL = new UUID(0, 0); // для теста микрофона
	static final Map<UUID, Long> LAST = new ConcurrentHashMap<>(); // кто и когда говорил

	private static final ExecutorService EXEC = Executors.newSingleThreadExecutor(r -> {
		Thread t = new Thread(r, "voice-playback");
		t.setDaemon(true);
		return t;
	});
	private static final Map<UUID, Voice> VOICES = new HashMap<>(); // только из EXEC

	private Playback() {}

	static void push(SoundPacket p) {
		VoiceConfig c = VoiceConfig.get();
		if (c.deafened) return;
		boolean local = p.sender().equals(LOCAL);
		String id = p.sender().toString();
		if (!local && c.mutedPlayers.contains(id)) return;

		float vol = p.volume() * c.masterVolume * (local ? 1f : c.playerVolumes.getOrDefault(id, 1f));
		LAST.put(p.sender(), System.currentTimeMillis());

		EXEC.execute(() -> {
			try {
				Voice v = VOICES.get(p.sender());
				if (v == null) {
					v = new Voice(c.outputDevice);
					VOICES.put(p.sender(), v);
				}
				v.play(p.data(), vol);
			} catch (Exception e) {
				Voice old = VOICES.remove(p.sender());
				if (old != null) old.close();
			}
		});
	}

	/** Закрыть все линии (после смены устройства вывода). */
	static void reset() {
		EXEC.execute(() -> {
			for (Voice v : VOICES.values()) v.close();
			VOICES.clear();
		});
	}

	private static final class Voice {
		final OpusDecoder dec;
		final SourceDataLine line;
		final short[] pcm = new short[VoiceClient.FRAME];
		final byte[] out = new byte[VoiceClient.FRAME * 2];

		Voice(String device) throws Exception {
			dec = new OpusDecoder(48000, 1);
			line = AudioDevices.openOut(device);
			line.open(VoiceClient.FORMAT, VoiceClient.FRAME * 2 * 6); // ~120 мс буфер
			line.start();
		}

		void play(byte[] data, float volume) throws Exception {
			int n = dec.decode(data, 0, data.length, pcm, 0, VoiceClient.FRAME, false);
			for (int i = 0; i < n; i++) {
				int s = Math.round(pcm[i] * volume);
				s = Math.max(-32768, Math.min(32767, s));
				out[i * 2] = (byte) s;
				out[i * 2 + 1] = (byte) (s >> 8);
			}
			if (line.available() >= n * 2) line.write(out, 0, n * 2); // буфер полон -> роняем кадр
		}

		void close() {
			try { line.close(); } catch (Exception ignored) {}
		}
	}
}
