package ru.example.voice;

import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;

/** Клиент -> сервер: один Opus-кадр (20 мс). */
public record MicPacket(byte[] data) implements CustomPayload {
	public static final Id<MicPacket> ID = new Id<>(Identifier.of(VoiceMod.MOD_ID, "mic"));
	public static final PacketCodec<RegistryByteBuf, MicPacket> CODEC =
			PacketCodec.tuple(PacketCodecs.BYTE_ARRAY, MicPacket::data, MicPacket::new);

	@Override
	public Id<? extends CustomPayload> getId() {
		return ID;
	}
}
