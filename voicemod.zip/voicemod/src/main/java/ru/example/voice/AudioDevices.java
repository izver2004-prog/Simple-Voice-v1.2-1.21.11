package ru.example.voice;

import java.util.ArrayList;
import java.util.List;
import javax.sound.sampled.*;

final class AudioDevices {
	private AudioDevices() {}

	static List<Mixer.Info> list(Class<? extends DataLine> cls) {
		List<Mixer.Info> r = new ArrayList<>();
		DataLine.Info li = new DataLine.Info(cls, VoiceClient.FORMAT);
		for (Mixer.Info i : AudioSystem.getMixerInfo()) {
			try {
				if (AudioSystem.getMixer(i).isLineSupported(li)) r.add(i);
			} catch (Exception ignored) {}
		}
		return r;
	}

	/** Имена устройств; первым идёт "" = по умолчанию. */
	static List<String> names(Class<? extends DataLine> cls) {
		List<String> r = new ArrayList<>();
		r.add("");
		for (Mixer.Info i : list(cls)) if (!r.contains(i.getName())) r.add(i.getName());
		return r;
	}

	static TargetDataLine openIn(String name) throws LineUnavailableException {
		if (name != null && !name.isEmpty()) {
			for (Mixer.Info i : list(TargetDataLine.class)) {
				if (i.getName().equals(name)) return AudioSystem.getTargetDataLine(VoiceClient.FORMAT, i);
			}
		}
		return AudioSystem.getTargetDataLine(VoiceClient.FORMAT);
	}

	static SourceDataLine openOut(String name) throws LineUnavailableException {
		if (name != null && !name.isEmpty()) {
			for (Mixer.Info i : list(SourceDataLine.class)) {
				if (i.getName().equals(name)) return AudioSystem.getSourceDataLine(VoiceClient.FORMAT, i);
			}
		}
		return AudioSystem.getSourceDataLine(VoiceClient.FORMAT);
	}
}
