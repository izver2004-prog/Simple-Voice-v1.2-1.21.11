package ru.example.voice.mc;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import ru.example.voice.core.Gfx;

final class MojGfx implements Gfx {
	private final GuiGraphicsExtractor g;
	private final Font font;

	MojGfx(GuiGraphicsExtractor g, Font font) {
		this.g = g;
		this.font = font;
	}

	@Override public void fill(int x1, int y1, int x2, int y2, int argb) { g.fill(x1, y1, x2, y2, argb); }

	@Override public void text(String s, int x, int y, int argb) { g.text(font, s, x, y, argb, true); }

	@Override public int textWidth(String s) { return font.width(s); }

	@Override public void scissor(int x1, int y1, int x2, int y2) { g.enableScissor(x1, y1, x2, y2); }

	@Override public void unscissor() { g.disableScissor(); }
}
