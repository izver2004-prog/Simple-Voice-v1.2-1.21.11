package ru.example.voice.mc;

import java.util.UUID;
import net.minecraft.core.UUIDUtil;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import ru.example.voice.core.Meta;

/** Сервер -> клиент: кадр от игрока + громкость по расстоянию. Формат одинаков во всех версиях. */
public record SoundPacket(UUID sender, float volume, byte[] data) implements CustomPacketPayload {
	public static final Type<SoundPacket> TYPE = new Type<>(Identifier.fromNamespaceAndPath(Meta.MOD_ID, "sound"));
	public static final StreamCodec<RegistryFriendlyByteBuf, SoundPacket> CODEC = StreamCodec.composite(
			UUIDUtil.STREAM_CODEC, SoundPacket::sender,
			ByteBufCodecs.FLOAT, SoundPacket::volume,
			ByteBufCodecs.BYTE_ARRAY, SoundPacket::data,
			SoundPacket::new);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
