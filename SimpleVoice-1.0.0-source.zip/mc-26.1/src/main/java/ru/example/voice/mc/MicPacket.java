package ru.example.voice.mc;

import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.Identifier;
import ru.example.voice.core.Meta;

/** Клиент -> сервер: Opus-кадр. Формат одинаков во всех версиях мода. */
public record MicPacket(byte[] data) implements CustomPacketPayload {
	public static final Type<MicPacket> TYPE = new Type<>(Identifier.fromNamespaceAndPath(Meta.MOD_ID, "mic"));
	public static final StreamCodec<RegistryFriendlyByteBuf, MicPacket> CODEC =
			StreamCodec.composite(ByteBufCodecs.BYTE_ARRAY, MicPacket::data, MicPacket::new);

	@Override
	public Type<? extends CustomPacketPayload> type() {
		return TYPE;
	}
}
