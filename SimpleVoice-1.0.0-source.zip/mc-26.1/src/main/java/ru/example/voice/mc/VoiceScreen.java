package ru.example.voice.mc;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import ru.example.voice.core.Ui;
import ru.example.voice.core.VoiceCore;

/** Тонкая обёртка: всё рисование и ввод — в core.Ui. */
public class VoiceScreen extends Screen {
	private final Ui ui = new Ui(VoiceCore.platform());

	public VoiceScreen() {
		super(Component.literal("Simple Voice"));
	}

	@Override
	public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float partialTick) {
		ui.render(new MojGfx(graphics, this.font), this.width, this.height, mouseX, mouseY);
	}

	// без @Override: если сигнатура в версии другая, мод всё равно соберётся
	public boolean mouseScrolled(double x, double y, double h, double v) {
		ui.scroll(v);
		return true;
	}

	public boolean shouldCloseOnEsc() {
		return !ui.capturing();
	}

	public boolean isPauseScreen() {
		return false;
	}

	@Override
	public void removed() {
		ui.onClose();
	}
}
