package ru.example.voice.mc;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.level.ServerPlayer;

public class VoiceMod implements ModInitializer {
	/** Дальность слышимости в блоках. */
	public static final double RANGE = 48.0;

	@Override
	public void onInitialize() {
		PayloadTypeRegistry.serverboundPlay().register(MicPacket.TYPE, MicPacket.CODEC);
		PayloadTypeRegistry.clientboundPlay().register(SoundPacket.TYPE, SoundPacket.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(MicPacket.TYPE, (payload, ctx) -> {
			ServerPlayer sender = ctx.player();
			if (payload.data().length > 1275) return;

			for (ServerPlayer p : ctx.server().getPlayerList().getPlayers()) {
				if (p == sender || p.level() != sender.level()) continue;
				double d2 = p.distanceToSqr(sender);
				if (d2 > RANGE * RANGE) continue;
				if (!ServerPlayNetworking.canSend(p, SoundPacket.TYPE)) continue;

				float vol = (float) (1.0 - Math.sqrt(d2) / RANGE);
				ServerPlayNetworking.send(p, new SoundPacket(sender.getUUID(), vol, payload.data()));
			}
		});
	}
}
