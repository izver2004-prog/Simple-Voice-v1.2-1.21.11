package ru.example.voice.mc;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.resources.Identifier;
import ru.example.voice.core.Hud;
import ru.example.voice.core.Meta;
import ru.example.voice.core.Platform;
import ru.example.voice.core.Playback;
import ru.example.voice.core.VoiceCore;

public class VoiceClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		VoiceCore.init(new Platform() {
			@Override public String target() { return "26.1"; }

			@Override public boolean canSend() { return ClientPlayNetworking.canSend(MicPacket.TYPE); }

			@Override public void sendMic(byte[] frame) {
				Minecraft.getInstance().execute(() -> {
					if (ClientPlayNetworking.canSend(MicPacket.TYPE)) ClientPlayNetworking.send(new MicPacket(frame));
				});
			}

			@Override public String nameOf(UUID id) {
				var c = Minecraft.getInstance().getConnection();
				PlayerInfo e = c == null ? null : c.getPlayerInfo(id);
				return e == null ? "?" : e.getProfile().name();
			}

			@Override public List<PlayerEntry> otherPlayers() {
				Minecraft mc = Minecraft.getInstance();
				if (mc.getConnection() == null || mc.player == null) return List.of();
				UUID self = mc.player.getUUID();
				return mc.getConnection().getOnlinePlayers().stream()
						.filter(e -> !e.getProfile().id().equals(self))
						.map(e -> new PlayerEntry(e.getProfile().id(), e.getProfile().name()))
						.sorted(Comparator.comparing(e -> e.name().toLowerCase(Locale.ROOT)))
						.toList();
			}

			@Override public void openMenu() { Minecraft.getInstance().setScreen(new VoiceScreen()); }
		});

		ClientTickEvents.END_CLIENT_TICK.register(mc -> VoiceCore.onTick(mc.screen == null));

		ClientPlayNetworking.registerGlobalReceiver(SoundPacket.TYPE,
				(p, ctx) -> Playback.push(p.sender(), p.volume(), p.data()));

		HudElementRegistry.addLast(Identifier.fromNamespaceAndPath(Meta.MOD_ID, "hud"), (graphics, delta) -> {
			Minecraft mc = Minecraft.getInstance();
			if (mc.player == null || mc.options.hideGui) return;
			Hud.render(new MojGfx(graphics, mc.font),
					mc.getWindow().getGuiScaledWidth(), mc.getWindow().getGuiScaledHeight());
		});
	}
}
