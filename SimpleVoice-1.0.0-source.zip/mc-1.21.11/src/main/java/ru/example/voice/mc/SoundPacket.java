package ru.example.voice.mc;

import java.util.UUID;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
import net.minecraft.util.Uuids;
import ru.example.voice.core.Meta;

/** Сервер -> клиент: кадр от игрока + громкость по расстоянию. Формат одинаков во всех версиях. */
public record SoundPacket(UUID sender, float volume, byte[] data) implements CustomPayload {
	public static final Id<SoundPacket> ID = new Id<>(Identifier.of(Meta.MOD_ID, "sound"));
	public static final PacketCodec<RegistryByteBuf, SoundPacket> CODEC = PacketCodec.tuple(
			Uuids.PACKET_CODEC, SoundPacket::sender,
			PacketCodecs.FLOAT, SoundPacket::volume,
			PacketCodecs.BYTE_ARRAY, SoundPacket::data,
			SoundPacket::new);

	@Override
	public Id<? extends CustomPayload> getId() {
		return ID;
	}
}
