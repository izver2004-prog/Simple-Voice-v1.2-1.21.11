package ru.example.voice.mc;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import ru.example.voice.core.Ui;
import ru.example.voice.core.VoiceCore;

/** Тонкая обёртка: всё рисование и ввод — в core.Ui. */
public class VoiceScreen extends Screen {
	private final Ui ui = new Ui(VoiceCore.platform());

	public VoiceScreen() {
		super(Text.literal("Simple Voice"));
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		ui.render(new YarnGfx(ctx, textRenderer), width, height, mouseX, mouseY);
	}

	// без @Override: если сигнатура в версии другая, мод всё равно соберётся
	public boolean mouseScrolled(double x, double y, double h, double v) {
		ui.scroll(v);
		return true;
	}

	public boolean shouldCloseOnEsc() {
		return !ui.capturing();
	}

	public boolean shouldPause() {
		return false;
	}

	@Override
	public void removed() {
		ui.onClose();
	}
}
