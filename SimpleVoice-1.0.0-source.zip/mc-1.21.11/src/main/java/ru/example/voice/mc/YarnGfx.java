package ru.example.voice.mc;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import ru.example.voice.core.Gfx;

final class YarnGfx implements Gfx {
	private final DrawContext ctx;
	private final TextRenderer tr;

	YarnGfx(DrawContext ctx, TextRenderer tr) {
		this.ctx = ctx;
		this.tr = tr;
	}

	@Override public void fill(int x1, int y1, int x2, int y2, int argb) { ctx.fill(x1, y1, x2, y2, argb); }

	@Override public void text(String s, int x, int y, int argb) { ctx.drawTextWithShadow(tr, s, x, y, argb); }

	@Override public int textWidth(String s) { return tr.getWidth(s); }

	@Override public void scissor(int x1, int y1, int x2, int y2) { ctx.enableScissor(x1, y1, x2, y2); }

	@Override public void unscissor() { ctx.disableScissor(); }
}
