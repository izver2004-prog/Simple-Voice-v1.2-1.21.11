package ru.example.voice.mc;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import ru.example.voice.core.Hud;
import ru.example.voice.core.Platform;
import ru.example.voice.core.Playback;
import ru.example.voice.core.VoiceCore;

public class VoiceClient implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		VoiceCore.init(new Platform() {
			@Override public String target() { return "1.21.11"; }

			@Override public boolean canSend() { return ClientPlayNetworking.canSend(MicPacket.ID); }

			@Override public void sendMic(byte[] frame) {
				MinecraftClient.getInstance().execute(() -> {
					if (ClientPlayNetworking.canSend(MicPacket.ID)) ClientPlayNetworking.send(new MicPacket(frame));
				});
			}

			@Override public String nameOf(UUID id) {
				var h = MinecraftClient.getInstance().getNetworkHandler();
				PlayerListEntry e = h == null ? null : h.getPlayerListEntry(id);
				return e == null ? "?" : e.getProfile().name();
			}

			@Override public List<PlayerEntry> otherPlayers() {
				MinecraftClient mc = MinecraftClient.getInstance();
				if (mc.getNetworkHandler() == null || mc.player == null) return List.of();
				UUID self = mc.player.getUuid();
				return mc.getNetworkHandler().getPlayerList().stream()
						.filter(e -> !e.getProfile().id().equals(self))
						.map(e -> new PlayerEntry(e.getProfile().id(), e.getProfile().name()))
						.sorted(Comparator.comparing(e -> e.name().toLowerCase(Locale.ROOT)))
						.toList();
			}

			@Override public void openMenu() { MinecraftClient.getInstance().setScreen(new VoiceScreen()); }
		});

		ClientTickEvents.END_CLIENT_TICK.register(mc -> VoiceCore.onTick(mc.currentScreen == null));

		ClientPlayNetworking.registerGlobalReceiver(SoundPacket.ID,
				(p, ctx) -> Playback.push(p.sender(), p.volume(), p.data()));

		HudRenderCallback.EVENT.register((ctx, tick) -> {
			MinecraftClient mc = MinecraftClient.getInstance();
			if (mc.player == null || mc.options.hudHidden) return;
			Hud.render(new YarnGfx(ctx, mc.textRenderer),
					mc.getWindow().getScaledWidth(), mc.getWindow().getScaledHeight());
		});
	}
}
