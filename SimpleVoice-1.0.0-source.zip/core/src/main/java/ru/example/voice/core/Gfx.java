package ru.example.voice.core;

/** Минимальный набор рисования; реализуется в каждой версии (имена классов Minecraft отличаются). */
public interface Gfx {
	void fill(int x1, int y1, int x2, int y2, int argb);

	/** Текст с тенью, цвет ARGB. */
	void text(String s, int x, int y, int argb);

	int textWidth(String s);

	void scissor(int x1, int y1, int x2, int y2);

	void unscissor();
}
