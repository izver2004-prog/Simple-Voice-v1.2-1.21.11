package ru.example.voice.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;

/** Настройки клиента, config/simplevoice.json (общий для всех версий). */
public final class VoiceConfig {
	public enum Mode { PTT, VOICE, ALWAYS }

	public Mode mode = Mode.PTT;
	public int pttKey = GLFW.GLFW_KEY_B;
	public int menuKey = GLFW.GLFW_KEY_V;
	public boolean micMuted = false;
	public boolean deafened = false;
	public boolean showHud = true;
	public String inputDevice = "";
	public String outputDevice = "";
	public transient boolean loopback = false;

	public float micVolume = 1f;
	public float pitch = 1f;
	public float tone = 0f;
	public float threshold = 0.25f;
	public int holdMs = 400;
	public int bitrateKbps = 24;

	public float masterVolume = 1f;
	public Set<String> mutedPlayers = new HashSet<>();
	public Map<String, Float> playerVolumes = new HashMap<>();

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static VoiceConfig instance;

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("simplevoice.json");
	}

	public static synchronized VoiceConfig get() {
		if (instance == null) {
			try {
				Path f = file();
				if (Files.exists(f)) instance = GSON.fromJson(Files.readString(f), VoiceConfig.class);
			} catch (Exception ignored) {}
			if (instance == null) instance = new VoiceConfig();
			if (instance.mode == null) instance.mode = Mode.PTT;
			if (instance.mutedPlayers == null) instance.mutedPlayers = new HashSet<>();
			if (instance.playerVolumes == null) instance.playerVolumes = new HashMap<>();
			if (instance.inputDevice == null) instance.inputDevice = "";
			if (instance.outputDevice == null) instance.outputDevice = "";
			if (instance.menuKey <= 0) instance.menuKey = GLFW.GLFW_KEY_V;
		}
		return instance;
	}

	public static void save() {
		try {
			Files.writeString(file(), GSON.toJson(get()));
		} catch (Exception ignored) {}
	}

	private static final ScheduledExecutorService SAVER = Executors.newSingleThreadScheduledExecutor(r -> {
		Thread t = new Thread(r, "voice-config-saver");
		t.setDaemon(true);
		return t;
	});
	private static ScheduledFuture<?> pending;
	private static boolean hookAdded;

	/** Сохранение в фоне через 400 мс после последнего изменения (не тормозит интерфейс). */
	public static synchronized void saveAsync() {
		if (!hookAdded) {
			hookAdded = true;
			Runtime.getRuntime().addShutdownHook(new Thread(() -> {
				if (pending != null && !pending.isDone()) save();
			}));
		}
		if (pending != null) pending.cancel(false);
		pending = SAVER.schedule(VoiceConfig::save, 400, TimeUnit.MILLISECONDS);
	}

	public void resetVoice() {
		micVolume = 1f; pitch = 1f; tone = 0f; threshold = 0.25f; holdMs = 400; bitrateKbps = 24;
	}
}
