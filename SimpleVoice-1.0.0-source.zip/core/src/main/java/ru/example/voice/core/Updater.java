package ru.example.voice.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import net.fabricmc.loader.api.FabricLoader;

/**
 * Установка версий прямо из меню: список берётся с Modrinth, файл скачивается в папку mods
 * и заменяет текущую сборку (на Windows замена происходит после закрытия игры).
 * Все сетевые операции идут в фоне, интерфейс не блокируется.
 */
public final class Updater {
	public enum Check { IDLE, CHECKING, READY, NONE, FAILED }

	public static final class Remote {
		public final String version, file, url, sha512;

		Remote(String version, String file, String url, String sha512) {
			this.version = version;
			this.file = file;
			this.url = url;
			this.sha512 = sha512;
		}
	}

	public static final class Entry {
		public volatile Check check = Check.IDLE;
		public volatile Remote remote;
		/** 0 — ничего, 1 — загрузка, 2 — готово, 3 — ошибка. */
		public volatile int phase;
		public volatile float progress;
		public volatile String msg = "";
	}

	private static final Map<String, Entry> ENTRIES = new LinkedHashMap<>();

	static {
		for (String f : Meta.SUPPORTED) ENTRIES.put(f, new Entry());
	}

	private Updater() {}

	public static Entry entry(String family) {
		return ENTRIES.get(family);
	}

	private static String ua() {
		return "SimpleVoice/" + Meta.modVersion() + " (" + Meta.GITHUB_REPO + ")";
	}

	// ---------- список версий ----------

	/** Запрашивает список версий, если ещё не запрашивали. */
	public static void ensureChecked() {
		for (Entry e : ENTRIES.values()) if (e.check != Check.IDLE) return;
		refresh();
	}

	public static synchronized void refresh() {
		for (Entry e : ENTRIES.values()) {
			if (e.check == Check.CHECKING || e.phase == 1) return; // уже идёт
		}
		for (Entry e : ENTRIES.values()) {
			e.check = Check.CHECKING;
			e.msg = "";
		}
		Ui.invalidate();
		Thread t = new Thread(Updater::doRefresh, "voice-updater-check");
		t.setDaemon(true);
		t.start();
	}

	private static void doRefresh() {
		try {
			String url = "https://api.modrinth.com/v2/project/" + Meta.MODRINTH_SLUG
					+ "/version?loaders=%5B%22fabric%22%5D";
			JsonArray arr = JsonParser.parseString(get(url)).getAsJsonArray();
			for (Map.Entry<String, Entry> me : ENTRIES.entrySet()) {
				String fam = me.getKey();
				Remote found = null;
				for (JsonElement el : arr) { // от новых к старым
					JsonObject v = el.getAsJsonObject();
					if (!supports(v, fam)) continue;
					found = parse(v);
					if (found != null) break;
				}
				me.getValue().remote = found;
				me.getValue().check = found == null ? Check.NONE : Check.READY;
			}
		} catch (Throwable t) {
			for (Entry e : ENTRIES.values()) e.check = Check.FAILED;
		}
		Ui.invalidate();
	}

	private static boolean supports(JsonObject v, String fam) {
		for (JsonElement g : v.getAsJsonArray("game_versions")) {
			String s = g.getAsString();
			if (s.equals(fam) || s.startsWith(fam + ".")) return true;
		}
		return false;
	}

	private static Remote parse(JsonObject v) {
		JsonArray files = v.getAsJsonArray("files");
		JsonObject pick = null;
		for (JsonElement f : files) {
			JsonObject o = f.getAsJsonObject();
			if (pick == null) pick = o;
			if (o.has("primary") && o.get("primary").getAsBoolean()) {
				pick = o;
				break;
			}
		}
		if (pick == null) return null;
		String file = pick.get("filename").getAsString();
		if (!file.matches("[A-Za-z0-9._+\\-]+\\.jar")) return null; // защита от странных имён
		String sha = pick.has("hashes") && pick.getAsJsonObject("hashes").has("sha512")
				? pick.getAsJsonObject("hashes").get("sha512").getAsString().toLowerCase(Locale.ROOT) : null;
		return new Remote(v.get("version_number").getAsString(), file, pick.get("url").getAsString(), sha);
	}

	/** Есть ли у серверной версии номер новее установленной. */
	public static boolean isNewer(String remoteVersion, String currentVersion) {
		int[] a = nums(remoteVersion), b = nums(currentVersion);
		for (int i = 0; i < Math.max(a.length, b.length); i++) {
			int x = i < a.length ? a[i] : 0, y = i < b.length ? b[i] : 0;
			if (x != y) return x > y;
		}
		return false;
	}

	private static int[] nums(String v) {
		if (v == null) return new int[0];
		v = v.trim();
		if (v.startsWith("v") || v.startsWith("V")) v = v.substring(1);
		int plus = v.indexOf('+');
		if (plus >= 0) v = v.substring(0, plus);
		String[] parts = v.split("\\.");
		int[] r = new int[parts.length];
		for (int i = 0; i < parts.length; i++) {
			try {
				r[i] = Integer.parseInt(parts[i].replaceAll("\\D.*$", ""));
			} catch (NumberFormatException e) {
				r[i] = 0;
			}
		}
		return r;
	}

	public static String shortVersion(String v) {
		if (v == null) return "";
		int plus = v.indexOf('+');
		if (plus >= 0) v = v.substring(0, plus);
		return v.startsWith("v") ? v.substring(1) : v;
	}

	// ---------- установка ----------

	public static void install(String family) {
		Entry e = ENTRIES.get(family);
		if (e == null || e.remote == null || e.phase == 1) return;
		e.phase = 1;
		e.progress = 0f;
		e.msg = "";
		Ui.invalidate();
		Remote r = e.remote;
		Thread t = new Thread(() -> {
			try {
				e.msg = doInstall(e, r);
				e.phase = 2;
			} catch (Throwable ex) {
				e.msg = "ошибка загрузки";
				e.phase = 3;
			}
			Ui.invalidate();
		}, "voice-updater-install");
		t.setDaemon(true);
		t.start();
	}

	private static String doInstall(Entry e, Remote r) throws Exception {
		Path mods = FabricLoader.getInstance().getGameDir().resolve("mods");
		Files.createDirectories(mods);
		Path fin = mods.resolve(r.file).normalize();
		Path part = mods.resolve(r.file + ".part").normalize();
		if (!fin.getParent().equals(mods.normalize())) throw new IllegalStateException("bad name");

		Path cur = runningJar();
		if (cur != null && cur.equals(fin)) return "уже установлена";

		HttpURLConnection c = (HttpURLConnection) URI.create(r.url).toURL().openConnection();
		c.setConnectTimeout(10000);
		c.setReadTimeout(20000);
		c.setRequestProperty("User-Agent", ua());
		if (c.getResponseCode() != 200) throw new IllegalStateException("HTTP " + c.getResponseCode());
		long total = c.getContentLengthLong();
		if (total > 64L * 1024 * 1024) throw new IllegalStateException("too big");

		MessageDigest md = MessageDigest.getInstance("SHA-512");
		long done = 0;
		int lastPct = -1;
		try (InputStream in = c.getInputStream(); OutputStream out = Files.newOutputStream(part)) {
			byte[] buf = new byte[32768];
			int n;
			while ((n = in.read(buf)) > 0) {
				out.write(buf, 0, n);
				md.update(buf, 0, n);
				done += n;
				if (done > 64L * 1024 * 1024) throw new IllegalStateException("too big");
				if (total > 0) {
					e.progress = done / (float) total;
					int pct = (int) (e.progress * 100);
					if (pct != lastPct && pct % 5 == 0) { // не дёргаем интерфейс на каждый блок
						lastPct = pct;
						Ui.invalidate();
					}
				}
			}
		}
		if (r.sha512 != null) {
			StringBuilder sb = new StringBuilder();
			for (byte b : md.digest()) sb.append(String.format("%02x", b));
			if (!sb.toString().equals(r.sha512)) {
				Files.deleteIfExists(part);
				throw new IllegalStateException("hash mismatch");
			}
		}
		return swap(cur, part, fin);
	}

	private static Path runningJar() {
		try {
			var origin = FabricLoader.getInstance().getModContainer(Meta.MOD_ID).get().getOrigin();
			for (Path p : origin.getPaths()) {
				if (Files.isRegularFile(p) && p.toString().endsWith(".jar")) return p.normalize();
			}
		} catch (Throwable ignored) {}
		return null;
	}

	/** Подменяет старый файл новым. Windows держит jar открытым, поэтому там замена после выхода из игры. */
	private static String swap(Path cur, Path part, Path fin) throws Exception {
		boolean windows = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
		if (cur == null) {
			Files.move(part, fin, StandardCopyOption.REPLACE_EXISTING);
			return "установлено — перезапустите игру";
		}
		if (!windows) {
			Files.deleteIfExists(cur); // на Linux/macOS открытый файл можно удалить сразу
			Files.move(part, fin, StandardCopyOption.REPLACE_EXISTING);
			return "установлено — перезапустите игру";
		}
		Path bat = FabricLoader.getInstance().getGameDir().resolve("simplevoice-swap.bat");
		String old = cur.toString(), p = part.toString(), f = fin.toString();
		String script = "@echo off\r\nchcp 65001 >nul\r\nping -n 4 127.0.0.1 >nul\r\n"
				+ "for /L %%i in (1,1,30) do (\r\n"
				+ "  if exist \"" + old + "\" (\r\n"
				+ "    del /f /q \"" + old + "\" >nul 2>&1\r\n"
				+ "    if exist \"" + old + "\" ping -n 2 127.0.0.1 >nul\r\n"
				+ "  )\r\n)\r\n"
				+ "if not exist \"" + old + "\" move /y \"" + p + "\" \"" + f + "\" >nul\r\n"
				+ "(goto) 2>nul & del \"%~f0\"\r\n";
		Files.writeString(bat, script, StandardCharsets.UTF_8);
		Runtime.getRuntime().addShutdownHook(new Thread(() -> {
			try {
				new ProcessBuilder("cmd.exe", "/c", "start", "", "/min", bat.toString()).start();
			} catch (Exception ignored) {}
		}));
		return "скачано — закройте игру, замена пройдёт сама";
	}

	private static String get(String url) throws Exception {
		HttpURLConnection c = (HttpURLConnection) URI.create(url).toURL().openConnection();
		c.setConnectTimeout(10000);
		c.setReadTimeout(15000);
		c.setRequestProperty("User-Agent", ua());
		c.setRequestProperty("Accept", "application/json");
		if (c.getResponseCode() != 200) throw new IllegalStateException("HTTP " + c.getResponseCode());
		try (InputStream in = c.getInputStream()) {
			return new String(in.readAllBytes(), StandardCharsets.UTF_8);
		}
	}
}
