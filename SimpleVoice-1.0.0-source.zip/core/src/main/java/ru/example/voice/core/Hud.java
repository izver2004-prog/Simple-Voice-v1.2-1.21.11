package ru.example.voice.core;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Индикатор на экране: микрофон + вертикальная полоска громкости слева от хотбара, список говорящих. */
public final class Hud {
	private static long last = System.nanoTime();
	private static float shown;
	private static final Map<UUID, String> LABELS = new HashMap<>();
	private static long labelsAt;

	private Hud() {}

	public static void render(Gfx g, int sw, int sh) {
		VoiceConfig c = VoiceConfig.get();
		if (!c.showHud) return;

		long now = System.nanoTime();
		float dt = Math.min(0.1f, (now - last) / 1e9f);
		last = now;

		boolean talking = VoiceCore.transmitting;
		float target = talking ? VoiceCore.level : 0f;
		shown = Draw.approach(shown, target, dt, target > shown ? 40f : 8f);

		// слева от хотбара (хотбар шириной 182, по центру), на его уровне
		int x0 = sw / 2 - 91;
		g.fill(x0 - 70, sh - 36, x0 - 36, sh - 2, 0x66000000);

		boolean off = c.micMuted || c.deafened;
		int col = off ? 0xFF9A9A9A : talking ? 0xFF55FF55 : 0xFFB5B5B5;
		Icons.mic(g, x0 - 62, sh - 14, col, off);

		int bx = x0 - 50, n = 10, lit = Math.round(shown * n);
		for (int i = 0; i < n; i++) {
			int y = sh - 6 - i * 3;
			int color = i < lit ? Draw.levelColor((i + 0.5f) / n) : 0xFF2B2B2B;
			g.fill(bx, y, bx + 5, y + 2, color);
		}

		// статус и список говорящих — слева сверху
		int y = 6;
		if (c.deafened) {
			g.text("Звук выключен", 6, y, 0xFFFF5555);
			y += 11;
		} else if (c.micMuted) {
			g.text("Микрофон выключен", 6, y, 0xFFFF5555);
			y += 11;
		}
		if (c.loopback) {
			g.text("Тест: вы слышите себя", 6, y, 0xFFFFDD55);
			y += 11;
		}
		Platform pl = VoiceCore.platform();
		long ms = System.currentTimeMillis();
		if (ms - labelsAt > 5000) {
			LABELS.clear();
			labelsAt = ms;
		}
		for (Map.Entry<UUID, Long> e : Playback.LAST.entrySet()) {
			if (e.getKey().equals(Playback.LOCAL) || ms - e.getValue() > 400) continue;
			String lab = LABELS.get(e.getKey());
			if (lab == null) {
				lab = "♪ " + (pl == null ? "?" : pl.nameOf(e.getKey()));
				LABELS.put(e.getKey(), lab);
			}
			g.text(lab, 6, y, 0xFFFFFFFF);
			y += 11;
		}
	}
}
