package ru.example.voice.core;

import io.github.jaredmdobson.concentus.OpusApplication;
import io.github.jaredmdobson.concentus.OpusEncoder;
import java.util.Arrays;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.TargetDataLine;
import org.lwjgl.glfw.GLFW;

/** Ядро клиента: захват микрофона, активация, кодирование. Не зависит от версии Minecraft. */
public final class VoiceCore {
	public static final AudioFormat FORMAT = new AudioFormat(48000f, 16, 1, true, false);
	public static final int FRAME = 960; // 20 мс

	public static volatile boolean pttHeld;
	public static volatile boolean transmitting;
	public static volatile boolean menuMic; // тест из меню: слышим себя, на сервер не шлём
	public static volatile float level;     // 0..1 для индикаторов

	private static Platform platform;
	private static boolean started, menuWas;

	private VoiceCore() {}

	public static Platform platform() { return platform; }

	public static synchronized void init(Platform p) {
		if (started) return;
		started = true;
		platform = p;
		VoiceConfig.get();
		AudioDevices.refreshAsync();
		Thread t = new Thread(VoiceCore::captureLoop, "voice-capture");
		t.setDaemon(true);
		t.start();
	}

	/** Вызывать каждый клиентский тик. noScreen = нет открытого экрана. */
	public static void onTick(boolean noScreen) {
		long win = GLFW.glfwGetCurrentContext();
		if (win == 0) return;
		VoiceConfig c = VoiceConfig.get();
		pttHeld = noScreen && c.pttKey > 0 && GLFW.glfwGetKey(win, c.pttKey) == GLFW.GLFW_PRESS;
		boolean menu = noScreen && c.menuKey > 0 && GLFW.glfwGetKey(win, c.menuKey) == GLFW.GLFW_PRESS;
		if (menu && !menuWas && platform != null) platform.openMenu();
		menuWas = menu;
	}

	/** Шкала индикатора 0..1 (одна для порога, меню и HUD). */
	public static float toMeter(float rms) {
		return Math.min(1f, (float) Math.sqrt(rms) * 1.5f);
	}

	private static void captureLoop() {
		while (true) {
			String dev = VoiceConfig.get().inputDevice;
			try (TargetDataLine mic = AudioDevices.openIn(dev)) {
				OpusEncoder enc = new OpusEncoder(48000, 1, OpusApplication.OPUS_APPLICATION_VOIP);
				enc.setComplexity(5); // легче для процессора, качество речи почти то же
				mic.open(FORMAT);
				mic.start();

				Effects fx = new Effects();
				byte[] raw = new byte[FRAME * 2];
				float[] f = new float[FRAME];
				short[] pcm = new short[FRAME];
				byte[] out = new byte[1275];
				int bitrate = -1;
				long lastLoud = 0;

				while (dev.equals(VoiceConfig.get().inputDevice)) {
					int read = 0;
					while (read < raw.length) {
						int n = mic.read(raw, read, raw.length - read);
						if (n <= 0) throw new IllegalStateException("mic closed");
						read += n;
					}
					VoiceConfig c = VoiceConfig.get();

					double sum = 0;
					for (int i = 0; i < FRAME; i++) {
						short s = (short) ((raw[i * 2] & 0xFF) | (raw[i * 2 + 1] << 8));
						float v = s / 32768f * c.micVolume;
						f[i] = v;
						sum += v * v;
					}
					float meter = toMeter((float) Math.sqrt(sum / FRAME));
					level = meter;

					long now = System.currentTimeMillis();
					boolean active;
					if (c.mode == VoiceConfig.Mode.ALWAYS) {
						active = true;
					} else if (c.mode == VoiceConfig.Mode.PTT) {
						active = pttHeld;
					} else {
						if (meter > c.threshold) lastLoud = now;
						active = now - lastLoud < c.holdMs;
					}
					if (c.micMuted) active = false;
					if (menuMic) active = true;
					transmitting = active && !menuMic;
					if (!active) continue;

					for (int i = 0; i < FRAME; i++) {
						float y = fx.process(f[i], c.pitch, c.tone);
						pcm[i] = (short) Math.max(-32768, Math.min(32767, Math.round(y * 32767f)));
					}
					if (bitrate != c.bitrateKbps) {
						bitrate = c.bitrateKbps;
						enc.setBitrate(bitrate * 1000);
					}
					int len = enc.encode(pcm, 0, FRAME, out, 0, out.length);
					byte[] frame = Arrays.copyOf(out, len);

					if (c.loopback || menuMic) Playback.push(Playback.LOCAL, 1f, frame);
					if (!menuMic && platform != null && platform.canSend()) platform.sendMic(frame);
				}
			} catch (Exception e) {
				transmitting = false;
				try { Thread.sleep(3000); } catch (InterruptedException ie) { return; }
			}
		}
	}
}
