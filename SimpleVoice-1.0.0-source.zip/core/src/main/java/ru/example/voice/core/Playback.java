package ru.example.voice.core;

import io.github.jaredmdobson.concentus.OpusDecoder;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.sound.sampled.SourceDataLine;

/** Воспроизведение: у каждого говорящего свой декодер и своя линия вывода. */
public final class Playback {
	public static final UUID LOCAL = new UUID(0, 0); // тест микрофона
	public static final Map<UUID, Long> LAST = new ConcurrentHashMap<>();

	private static final ExecutorService EXEC = Executors.newSingleThreadExecutor(r -> {
		Thread t = new Thread(r, "voice-playback");
		t.setDaemon(true);
		return t;
	});
	private static final Map<UUID, Voice> VOICES = new HashMap<>(); // только из EXEC

	private Playback() {}

	public static void push(UUID sender, float volume, byte[] data) {
		VoiceConfig c = VoiceConfig.get();
		boolean local = sender.equals(LOCAL);
		if (c.deafened && !local) return;
		String id = sender.toString();
		if (!local && c.mutedPlayers.contains(id)) return;

		float vol = local ? volume
				: volume * c.masterVolume * c.playerVolumes.getOrDefault(id, 1f);
		LAST.put(sender, System.currentTimeMillis());

		EXEC.execute(() -> {
			try {
				Voice v = VOICES.get(sender);
				if (v == null) {
					v = new Voice(c.outputDevice);
					VOICES.put(sender, v);
				}
				v.play(data, vol);
			} catch (Exception e) {
				Voice old = VOICES.remove(sender);
				if (old != null) old.close();
			}
		});
	}

	/** Закрыть все линии (после смены устройства вывода). */
	public static void reset() {
		EXEC.execute(() -> {
			for (Voice v : VOICES.values()) v.close();
			VOICES.clear();
		});
	}

	private static final class Voice {
		final OpusDecoder dec;
		final SourceDataLine line;
		final short[] pcm = new short[VoiceCore.FRAME];
		final byte[] out = new byte[VoiceCore.FRAME * 2];

		Voice(String device) throws Exception {
			dec = new OpusDecoder(48000, 1);
			line = AudioDevices.openOut(device);
			line.open(VoiceCore.FORMAT, VoiceCore.FRAME * 2 * 6);
			line.start();
		}

		void play(byte[] data, float volume) throws Exception {
			int n = dec.decode(data, 0, data.length, pcm, 0, VoiceCore.FRAME, false);
			for (int i = 0; i < n; i++) {
				int s = Math.round(pcm[i] * volume);
				s = Math.max(-32768, Math.min(32767, s));
				out[i * 2] = (byte) s;
				out[i * 2 + 1] = (byte) (s >> 8);
			}
			if (line.available() >= n * 2) line.write(out, 0, n * 2);
		}

		void close() {
			try { line.close(); } catch (Exception ignored) {}
		}
	}
}
