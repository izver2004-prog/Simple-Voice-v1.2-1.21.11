package ru.example.voice.core;

import java.util.List;
import java.util.UUID;

/** Всё, что зависит от версии Minecraft. Реализуется в модуле каждой версии. */
public interface Platform {
	record PlayerEntry(UUID id, String name) {}

	/** Версия Minecraft, под которую собран этот jar (например "26.2"). */
	String target();

	/** Подключены ли мы к серверу, на котором стоит мод. */
	boolean canSend();

	/** Отправить Opus-кадр на сервер (можно вызывать из любого потока). */
	void sendMic(byte[] frame);

	String nameOf(UUID id);

	List<PlayerEntry> otherPlayers();

	void openMenu();
}
