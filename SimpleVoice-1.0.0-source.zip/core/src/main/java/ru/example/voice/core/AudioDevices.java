package ru.example.voice.core;

import java.util.ArrayList;
import java.util.List;
import javax.sound.sampled.*;

final class AudioDevices {
	private static volatile List<String> inNames = List.of("");
	private static volatile List<String> outNames = List.of("");
	private static volatile boolean refreshing;

	private AudioDevices() {}

	static List<Mixer.Info> list(Class<? extends DataLine> cls) {
		List<Mixer.Info> r = new ArrayList<>();
		DataLine.Info li = new DataLine.Info(cls, VoiceCore.FORMAT);
		for (Mixer.Info i : AudioSystem.getMixerInfo()) {
			try {
				if (AudioSystem.getMixer(i).isLineSupported(li)) r.add(i);
			} catch (Exception ignored) {}
		}
		return r;
	}

	private static List<String> scan(Class<? extends DataLine> cls) {
		List<String> r = new ArrayList<>();
		r.add("");
		for (Mixer.Info i : list(cls)) if (!r.contains(i.getName())) r.add(i.getName());
		return List.copyOf(r);
	}

	/** Обновляет списки в фоне, чтобы клики в меню не тормозили. */
	static void refreshAsync() {
		if (refreshing) return;
		refreshing = true;
		Thread t = new Thread(() -> {
			try {
				inNames = scan(TargetDataLine.class);
				outNames = scan(SourceDataLine.class);
			} catch (Throwable ignored) {
			} finally {
				refreshing = false;
			}
		}, "voice-devices");
		t.setDaemon(true);
		t.start();
	}

	/** Из кэша, мгновенно. */
	static List<String> names(Class<? extends DataLine> cls) {
		return cls == TargetDataLine.class ? inNames : outNames;
	}

	static TargetDataLine openIn(String name) throws LineUnavailableException {
		if (name != null && !name.isEmpty()) {
			for (Mixer.Info i : list(TargetDataLine.class)) {
				if (i.getName().equals(name)) return AudioSystem.getTargetDataLine(VoiceCore.FORMAT, i);
			}
		}
		return AudioSystem.getTargetDataLine(VoiceCore.FORMAT);
	}

	static SourceDataLine openOut(String name) throws LineUnavailableException {
		if (name != null && !name.isEmpty()) {
			for (Mixer.Info i : list(SourceDataLine.class)) {
				if (i.getName().equals(name)) return AudioSystem.getSourceDataLine(VoiceCore.FORMAT, i);
			}
		}
		return AudioSystem.getSourceDataLine(VoiceCore.FORMAT);
	}
}
