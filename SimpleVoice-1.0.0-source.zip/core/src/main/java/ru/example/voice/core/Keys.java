package ru.example.voice.core;

import java.util.Locale;
import org.lwjgl.glfw.GLFW;

final class Keys {
	private Keys() {}

	/** Допустимые коды клавиш GLFW (чтобы не вызывать glfwGetKey с неверным кодом). */
	static boolean valid(int k) {
		return k == 32 || k == 39 || (k >= 44 && k <= 57) || k == 59 || k == 61 || (k >= 65 && k <= 93)
				|| k == 96 || k == 161 || k == 162 || (k >= 256 && k <= 269) || (k >= 280 && k <= 284)
				|| (k >= 290 && k <= 314) || (k >= 320 && k <= 348);
	}

	static String name(int k) {
		switch (k) {
			case GLFW.GLFW_KEY_SPACE: return "Пробел";
			case GLFW.GLFW_KEY_LEFT_SHIFT: return "Левый Shift";
			case GLFW.GLFW_KEY_RIGHT_SHIFT: return "Правый Shift";
			case GLFW.GLFW_KEY_LEFT_CONTROL: return "Левый Ctrl";
			case GLFW.GLFW_KEY_RIGHT_CONTROL: return "Правый Ctrl";
			case GLFW.GLFW_KEY_LEFT_ALT: return "Левый Alt";
			case GLFW.GLFW_KEY_RIGHT_ALT: return "Правый Alt";
			case GLFW.GLFW_KEY_TAB: return "Tab";
			case GLFW.GLFW_KEY_CAPS_LOCK: return "Caps Lock";
			case GLFW.GLFW_KEY_ENTER: return "Enter";
			case GLFW.GLFW_KEY_BACKSPACE: return "Backspace";
			case GLFW.GLFW_KEY_UP: return "Стрелка вверх";
			case GLFW.GLFW_KEY_DOWN: return "Стрелка вниз";
			case GLFW.GLFW_KEY_LEFT: return "Стрелка влево";
			case GLFW.GLFW_KEY_RIGHT: return "Стрелка вправо";
			default:
				if (k >= GLFW.GLFW_KEY_F1 && k <= GLFW.GLFW_KEY_F25) return "F" + (k - GLFW.GLFW_KEY_F1 + 1);
				String n = GLFW.glfwGetKeyName(k, 0);
				return n != null ? n.toUpperCase(Locale.ROOT) : "Клавиша " + k;
		}
	}
}
