package ru.example.voice.core;

import java.util.List;
import net.fabricmc.loader.api.FabricLoader;

/** Версии и автоопределение версий мода и Minecraft. */
public final class Meta {
	public static final String MOD_ID = "simplevoice";
	/** ЗАМЕНИТЕ на slug вашего проекта на Modrinth: оттуда вкладка «Порты» скачивает версии. */
	public static final String MODRINTH_SLUG = "simple-voice";
	/** Только для User-Agent при обращении к Modrinth (владелец/репозиторий). */
	public static final String GITHUB_REPO = "YOUR_NAME/simple-voice";
	/** Семейства версий, под которые существуют сборки. */
	public static final List<String> SUPPORTED = List.of("1.21.11", "26.1", "26.2", "26.3");

	private static String modV, mcV;

	private Meta() {}

	private static String versionOf(String id) {
		try {
			return FabricLoader.getInstance().getModContainer(id)
					.map(c -> c.getMetadata().getVersion().getFriendlyString()).orElse("?");
		} catch (Throwable t) {
			return "?";
		}
	}

	public static synchronized String modVersion() {
		if (modV == null) modV = versionOf(MOD_ID);
		return modV;
	}

	public static synchronized String mcVersion() {
		if (mcV == null) mcV = versionOf("minecraft");
		return mcV;
	}

	/** 26.1.2 -> 26.1, 1.21.11 -> 1.21.11, неизвестная -> null. */
	public static String family(String v) {
		if (v == null) return null;
		for (String s : SUPPORTED) {
			if (v.equals(s) || v.startsWith(s + ".") || v.startsWith(s + "-")) return s;
		}
		return null;
	}
}
