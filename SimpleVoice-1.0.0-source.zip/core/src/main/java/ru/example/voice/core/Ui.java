package ru.example.voice.core;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;
import java.util.function.Supplier;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.TargetDataLine;
import org.lwjgl.glfw.GLFW;

/**
 * Меню мода: тёмный интерфейс в духе Minecraft, плавные анимации.
 * Не зависит от версии Minecraft: рисует через Gfx, ввод читает напрямую из GLFW.
 *
 * Оптимизация: подписи и их ширина кэшируются и пересчитываются только при изменении (RV),
 * цвета кнопок пересчитываются только пока идёт анимация, клавиши опрашиваются лишь при выборе кнопки,
 * списки устройств и игроков кэшируются, файл конфига пишется в фоне.
 */
public final class Ui {
	private static final String[] TABS = {"Настройки", "Голос", "Звук", "Порты"};
	private static final int PW = 290, ROW = 20, GAP = 4, TABW = (PW - 24) / 4;
	private static final int ACCENT = 0xFF5B8CFF;
	private static int tab = 0;

	/** Номер «ревизии» интерфейса: растёт при любом изменении, сбрасывает кэш подписей. */
	private static volatile int RV = 0;

	public static void invalidate() {
		RV++;
	}

	private final Platform pl;
	private final VoiceConfig cfg = VoiceConfig.get();
	private final List<W> ws = new ArrayList<>();
	private final boolean[] keyWas = new boolean[GLFW.GLFW_KEY_LAST + 1];
	private final float[] tabHov = new float[TABS.length];

	private long last = System.nanoTime();
	private float open, tabX = -1f, scroll, scrollTarget;
	private int contentH, builtTab = -1;
	private int capturing; // 0 нет, 1 кнопка разговора, 2 кнопка меню
	private W dragging;
	private boolean mouseWas, first = true;
	private String toast = "";
	private float toastT;
	private int px, py, ph, vx, vy, vw, vh;

	private List<Platform.PlayerEntry> players = List.of(), builtPlayers = List.of();
	private long playersAt;
	private String armed = "";
	private long armedUntil;

	// кэш строк версии в шапке
	private String vLine1, vLine2;
	private int vRev = -1;

	public Ui(Platform pl) {
		this.pl = pl;
		AudioDevices.refreshAsync(); // обновим список устройств в фоне
		invalidate();
	}

	public boolean capturing() { return capturing != 0; }

	public void onClose() {
		VoiceCore.menuMic = false;
		VoiceConfig.saveAsync();
	}

	public void scroll(double amount) {
		scrollTarget -= (float) amount * 18f;
		clampScroll();
	}

	private void clampScroll() {
		float max = Math.max(0, contentH - GAP - vh);
		scrollTarget = Math.max(0f, Math.min(max, scrollTarget));
	}

	// ======================= кадр =======================

	public void render(Gfx g, int sw, int sh, int mx, int my) {
		long now = System.nanoTime();
		float dt = Math.min(0.1f, (now - last) / 1e9f);
		last = now;
		open = Draw.approach(open, 1f, dt, 14f);
		if (toastT > 0) {
			toastT -= dt;
			if (toastT <= 0) invalidate();
		}
		if (!armed.isEmpty() && now > armedUntil) {
			armed = "";
			invalidate();
		}

		// геометрия
		ph = Math.min(sh - 16, 262);
		px = (sw - PW) / 2;
		py = (sh - ph) / 2 + Math.round((1f - open) * 10f);
		vx = px + 12;
		vy = py + 48;
		vw = PW - 24;
		vh = ph - 48 - 18;

		pollInput(mx, my);

		if (tab == 2 && now - playersAt > 500_000_000L) {
			players = pl.otherPlayers();
			playersAt = now;
		}
		if (builtTab != tab || (tab == 2 && !players.equals(builtPlayers))) build();
		clampScroll();
		scroll = Draw.approach(scroll, scrollTarget, dt, 18f);

		g.fill(0, 0, sw, sh, ((int) (open * 176f) << 24));

		versionLabel(g);

		Draw.bevel(g, px, py, PW, ph, 0xF2141416, 0xFF2E2E33, 0xFF0C0C0E, 0xFF000000);
		g.text("Simple Voice", px + 12, py + 9, 0xFFFFFFFF);
		String v = "v" + Meta.modVersion();
		g.text(v, px + PW - 12 - g.textWidth(v), py + 9, 0xFF7C7C86);

		drawTabs(g, mx, my, dt);

		g.scissor(vx, vy, vx + vw, vy + vh);
		int sy = Math.round(scroll);
		boolean inView = mx >= vx && mx < vx + vw && my >= vy && my < vy + vh;
		for (int i = 0, n = ws.size(); i < n; i++) {
			W w = ws.get(i);
			w.ax = vx + w.x;
			w.ay = vy + w.y - sy;
			if (w.ay + w.h < vy || w.ay > vy + vh) continue;
			w.tick();
			boolean hover = inView && w.clickable && w.enabled && w.hit(mx, my) && (dragging == null || dragging == w);
			w.draw(g, hover, dt);
		}
		g.unscissor();

		float maxS = Math.max(0, contentH - GAP - vh);
		if (maxS > 0) {
			int th = Math.max(14, (int) (vh * (vh / (float) (contentH - GAP))));
			int ty = vy + (int) ((vh - th) * (scroll / maxS));
			g.fill(px + PW - 8, vy, px + PW - 5, vy + vh, 0xFF0A0A0B);
			g.fill(px + PW - 8, ty, px + PW - 5, ty + th, 0xFF5A5A63);
		}

		g.fill(px + 12, py + ph - 17, px + PW - 12, py + ph - 16, 0xFF2A2A2F);
		g.text(capturing != 0 ? "Нажмите клавишу…  Esc — отмена" : "Esc — закрыть", px + 12, py + ph - 13, 0xFF6E6E78);
		if (toastT > 0 && !toast.isEmpty()) {
			int a = (int) (Math.min(1f, toastT) * 255f);
			g.text(toast, px + PW - 12 - g.textWidth(toast), py + ph - 13, (a << 24) | 0x7CE38B);
		}
	}

	private void versionLabel(Gfx g) {
		if (vRev != RV || vLine1 == null) {
			String mc = Meta.mcVersion();
			vLine1 = "Simple Voice v" + Meta.modVersion() + "  ·  Minecraft " + mc + " (определено автоматически)";
			boolean ok = pl.target().equals(Meta.family(mc));
			vLine2 = ok ? null : "Эта сборка для " + pl.target() + ". Нужная версия — во вкладке «Порты»";
			vOk = ok;
			vRev = RV;
		}
		g.text(vLine1, 6, 6, vOk ? 0xFF7CE38B : 0xFFFFB454);
		if (vLine2 != null) g.text(vLine2, 6, 17, 0xFFFFB454);
	}

	private boolean vOk;

	private void drawTabs(Gfx g, int mx, int my, float dt) {
		int ty = py + 24;
		g.fill(px + 12, ty + 17, px + PW - 12, ty + 18, 0xFF2A2A2F);
		for (int i = 0; i < TABS.length; i++) {
			int x = px + 12 + i * TABW;
			boolean hov = mx >= x && mx < x + TABW && my >= ty && my < ty + 18;
			tabHov[i] = Draw.approach(tabHov[i], hov ? 1f : 0f, dt, 16f);
			int col = i == tab ? 0xFFFFFFFF : Draw.lerp(0xFF8A8A94, 0xFFD6D6DE, tabHov[i]);
			Draw.centered(g, TABS[i], x + TABW / 2, ty + 5, col);
		}
		float target = px + 12 + tab * TABW;
		tabX = tabX < 0 ? target : Draw.approach(tabX, target, dt, 16f);
		g.fill(Math.round(tabX) + 4, ty + 16, Math.round(tabX) + TABW - 4, ty + 18, ACCENT);
	}

	// ======================= ввод =======================

	private void pollInput(int mx, int my) {
		long win = GLFW.glfwGetCurrentContext();
		if (win == 0) return;
		boolean down = GLFW.glfwGetMouseButton(win, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
		if (first) {
			mouseWas = down;
			first = false;
		}
		if (down && !mouseWas) {
			mouseDown(mx, my);
		} else if (!down && mouseWas) {
			if (dragging != null) {
				dragging.up();
				VoiceConfig.saveAsync();
				invalidate();
			}
			dragging = null;
		} else if (down && dragging != null) {
			dragging.drag(mx, my);
			invalidate();
		}
		mouseWas = down;

		// клавиши опрашиваем только пока выбираем кнопку
		if (capturing != 0) {
			for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
				if (!Keys.valid(k)) continue;
				boolean p = GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
				if (p && !keyWas[k]) {
					applyKey(k);
					break;
				}
				keyWas[k] = p;
			}
		}
	}

	private void startCapture(int which) {
		long win = GLFW.glfwGetCurrentContext();
		if (win != 0) {
			for (int k = GLFW.GLFW_KEY_SPACE; k <= GLFW.GLFW_KEY_LAST; k++) {
				if (Keys.valid(k)) keyWas[k] = GLFW.glfwGetKey(win, k) == GLFW.GLFW_PRESS;
			}
		}
		capturing = which;
	}

	private void applyKey(int k) {
		if (k == GLFW.GLFW_KEY_ESCAPE) {
			toast("Отменено");
		} else if (capturing == 1) {
			cfg.pttKey = k;
			toast("Кнопка разговора: " + Keys.name(k));
		} else {
			cfg.menuKey = k;
			toast("Кнопка меню: " + Keys.name(k));
		}
		capturing = 0;
		VoiceConfig.saveAsync();
		invalidate();
	}

	private void mouseDown(int mx, int my) {
		invalidate();
		int ty = py + 24;
		if (my >= ty && my < ty + 18 && mx >= px + 12 && mx < px + 12 + TABW * TABS.length) {
			int i = Math.max(0, Math.min(TABS.length - 1, (mx - (px + 12)) / TABW));
			if (i != tab) {
				tab = i;
				scrollTarget = 0;
				scroll = 0;
				capturing = 0;
			}
			return;
		}
		if (mx >= vx && mx < vx + vw && my >= vy && my < vy + vh) {
			for (int i = ws.size() - 1; i >= 0; i--) {
				W w = ws.get(i);
				if (w.clickable && w.enabled && w.hit(mx, my)) {
					w.down(mx, my);
					dragging = w;
					return;
				}
			}
		}
	}

	private void toast(String s) {
		toast = s;
		toastT = 2.5f;
	}

	// ======================= построение вкладок =======================

	private void build() {
		ws.clear();
		builtTab = tab;
		builtPlayers = players;
		int w = PW - 24;
		switch (tab) {
			case 0: contentH = buildSettings(w); break;
			case 1: contentH = buildVoice(w); break;
			case 2: contentH = buildSound(w); break;
			default: Updater.ensureChecked(); contentH = buildPorts(w); break;
		}
		invalidate();
	}

	private int btn(int y, int w, Supplier<String> label, Runnable r) {
		Btn b = new Btn(label, r);
		b.x = 0; b.y = y; b.w = w; b.h = ROW;
		ws.add(b);
		return y + ROW + GAP;
	}

	private int tog(int y, int w, String text, BooleanSupplier get, Consumer<Boolean> set) {
		Tog t = new Tog(text, get, set);
		t.x = 0; t.y = y; t.w = w; t.h = ROW;
		ws.add(t);
		return y + ROW + GAP;
	}

	private int sld(int y, int w, double min, double max, DoubleSupplier get, DoubleConsumer set,
					DoubleFunction<String> label) {
		Sld s = new Sld(min, max, get, set, label);
		s.x = 0; s.y = y; s.w = w; s.h = ROW;
		ws.add(s);
		return y + ROW + GAP;
	}

	private int txt(int y, int w, String[] lines, int color) {
		Txt t = new Txt(lines, color);
		t.x = 0; t.y = y; t.w = w; t.h = lines.length * 11;
		ws.add(t);
		return y + t.h + GAP;
	}

	private int buildSettings(int w) {
		int y = 0;
		y = btn(y, w, () -> "Активация: " + modeName(cfg.mode), () -> {
			cfg.mode = VoiceConfig.Mode.values()[(cfg.mode.ordinal() + 1) % VoiceConfig.Mode.values().length];
			VoiceConfig.saveAsync();
		});
		y = btn(y, w, () -> capturing == 1 ? "Нажмите кнопку…" : "Кнопка разговора: " + Keys.name(cfg.pttKey),
				() -> startCapture(1));
		y = btn(y, w, () -> capturing == 2 ? "Нажмите кнопку…" : "Кнопка меню: " + Keys.name(cfg.menuKey),
				() -> startCapture(2));
		y = btn(y, w, () -> "Микрофон: " + shortName(cfg.inputDevice), () -> {
			cfg.inputDevice = cycle(AudioDevices.names(TargetDataLine.class), cfg.inputDevice);
			VoiceConfig.saveAsync();
		});
		y = btn(y, w, () -> "Вывод: " + shortName(cfg.outputDevice), () -> {
			cfg.outputDevice = cycle(AudioDevices.names(SourceDataLine.class), cfg.outputDevice);
			Playback.reset();
			VoiceConfig.saveAsync();
		});
		y = tog(y, w, "Микрофон выключен", () -> cfg.micMuted, v -> { cfg.micMuted = v; VoiceConfig.saveAsync(); });
		y = tog(y, w, "Индикатор на экране", () -> cfg.showHud, v -> { cfg.showHud = v; VoiceConfig.saveAsync(); });

		Tog t = new Tog("Слышать себя", () -> cfg.loopback, v -> cfg.loopback = v);
		t.x = 0; t.y = y; t.w = w - 24; t.h = ROW;
		ws.add(t);
		MicBtn m = new MicBtn();
		m.x = w - 20; m.y = y; m.w = 20; m.h = ROW;
		ws.add(m);
		y += ROW + GAP;
		y = txt(y, w, new String[]{"Кнопка-микрофон справа: говорить и слышать себя",
				"прямо в меню (лучше в наушниках)."}, 0xFF7C7C86);
		return y;
	}

	private int buildVoice(int w) {
		int y = 0;
		y = sld(y, w, 0, 2, () -> cfg.micVolume, v -> cfg.micVolume = (float) v,
				v -> "Громкость микрофона: " + Math.round(v * 100) + "%");
		y = sld(y, w, 0.5, 2.0, () -> cfg.pitch, v -> cfg.pitch = (float) v,
				v -> String.format(java.util.Locale.ROOT, "Высота голоса: ×%.2f", v));
		y = sld(y, w, -1, 1, () -> cfg.tone, v -> cfg.tone = (float) v,
				v -> "Тон: " + (v < -0.05 ? "глухой" : v > 0.05 ? "яркий" : "нейтральный")
						+ " (" + Math.round(v * 100) + ")");
		y = sld(y, w, 0, 1, () -> cfg.threshold, v -> cfg.threshold = (float) v,
				v -> "Порог активации голосом: " + Math.round(v * 100) + "%");
		y = sld(y, w, 100, 1500, () -> cfg.holdMs, v -> cfg.holdMs = (int) (Math.round(v / 50) * 50),
				v -> "Удержание после речи: " + (Math.round(v / 50) * 50) + " мс");
		y = sld(y, w, 8, 64, () -> cfg.bitrateKbps, v -> cfg.bitrateKbps = (int) Math.round(v),
				v -> "Качество (битрейт): " + Math.round(v) + " кбит/с");

		Meter m = new Meter();
		m.x = 0; m.y = y; m.w = w; m.h = 10;
		ws.add(m);
		y += 10 + GAP + 4;
		y = btn(y, w, () -> "Сбросить настройки голоса", () -> {
			cfg.resetVoice();
			VoiceConfig.saveAsync();
		});
		return y;
	}

	private int buildSound(int w) {
		int y = 0;
		y = sld(y, w, 0, 2, () -> cfg.masterVolume, v -> cfg.masterVolume = (float) v,
				v -> "Общая громкость игроков: " + Math.round(v * 100) + "%");
		y = tog(y, w, "Отключить звук (не слышать никого)", () -> cfg.deafened,
				v -> { cfg.deafened = v; VoiceConfig.saveAsync(); });
		y = txt(y, w, new String[]{"Игроки (" + players.size() + ")"}, 0xFFFFFFFF);
		if (players.isEmpty()) {
			y = txt(y, w, new String[]{"Других игроков нет."}, 0xFF7C7C86);
		}
		for (Platform.PlayerEntry p : players) {
			String key = p.id().toString();
			String name = p.name();
			Sld s = new Sld(0, 2, () -> cfg.playerVolumes.getOrDefault(key, 1f),
					v -> cfg.playerVolumes.put(key, (float) v), v -> name + " " + Math.round(v * 100) + "%");
			s.x = 0; s.y = y; s.w = w - 70; s.h = ROW;
			ws.add(s);
			Btn mute = new Btn(() -> cfg.mutedPlayers.contains(key) ? "Мут" : "Звук", () -> {
				if (!cfg.mutedPlayers.remove(key)) cfg.mutedPlayers.add(key);
				VoiceConfig.saveAsync();
			});
			mute.warn = () -> cfg.mutedPlayers.contains(key);
			mute.x = w - 66; mute.y = y; mute.w = 66; mute.h = ROW;
			ws.add(mute);
			y += ROW + GAP;
		}
		return y;
	}

	private int buildPorts(int w) {
		String mc = Meta.mcVersion();
		String fam = Meta.family(mc);
		String target = pl.target();
		int y = 0;
		y = txt(y, w, new String[]{"Ваша версия: Minecraft " + mc + (fam == null ? "  (сборки нет)" : "")},
				fam == null ? 0xFFFFB454 : 0xFF7CE38B);
		y = txt(y, w, new String[]{"Эта сборка: для Minecraft " + target},
				target.equals(fam) ? 0xFF7CE38B : 0xFFFFB454);
		for (String v : Meta.SUPPORTED) {
			final boolean current = v.equals(target);
			PortRow r = new PortRow(v, current);
			r.x = 0; r.y = y; r.w = w; r.h = 22;
			ws.add(r);

			Btn b = new Btn(() -> actionLabel(v, current), () -> doAction(v, current));
			b.active = () -> actionActive(v, current);
			b.x = w - 84; b.y = y + 2; b.w = 80; b.h = 18;
			ws.add(b);
			y += 26;
		}
		y = btn(y + 2, w, () -> "Обновить список", Updater::refresh);
		y = txt(y, w, new String[]{"Мод скачает выбранную версию с Modrinth",
				"и заменит эту сборку после перезапуска.",
				"Запускайте Minecraft нужной версии."}, 0xFF7C7C86);
		return y;
	}

	private boolean isArmed(String v) {
		return armed.equals(v);
	}

	private String actionLabel(String v, boolean current) {
		Updater.Entry e = Updater.entry(v);
		if (e.phase == 1) return "Загрузка…";
		if (e.phase == 2) return "Готово";
		if (e.phase == 3) return "Повторить";
		switch (e.check) {
			case READY:
				if (current) return newer(e) ? "Обновить" : "Актуальна";
				return isArmed(v) ? "Точно?" : "Установить";
			case CHECKING: return "…";
			default: return "—";
		}
	}

	private boolean actionActive(String v, boolean current) {
		Updater.Entry e = Updater.entry(v);
		if (e.phase == 1 || e.phase == 2) return false;
		if (e.phase == 3) return true;
		if (e.check != Updater.Check.READY) return false;
		return !current || newer(e);
	}

	private boolean newer(Updater.Entry e) {
		return e.remote != null && Updater.isNewer(e.remote.version, Meta.modVersion());
	}

	private void doAction(String v, boolean current) {
		Updater.Entry e = Updater.entry(v);
		if (e.phase == 3 || current || isArmed(v)) {
			armed = "";
			Updater.install(v);
			return;
		}
		// установка другой версии заменяет текущую сборку: просим подтвердить вторым нажатием
		armed = v;
		armedUntil = System.nanoTime() + 4_000_000_000L;
	}

	private String portStatus(String v, boolean current) {
		Updater.Entry e = Updater.entry(v);
		if (e.phase == 1) return "загрузка " + (int) (e.progress * 100) + "%";
		if (e.phase == 2 || e.phase == 3) return e.msg;
		switch (e.check) {
			case CHECKING: return "проверка…";
			case FAILED: return "нет связи";
			case NONE: return current ? "эта сборка" : "не опубликована";
			case READY:
				String rv = Updater.shortVersion(e.remote.version);
				if (current) return newer(e) ? "эта сборка, есть " + rv : "эта сборка, актуальна";
				return "доступна " + rv;
			default: return "";
		}
	}

	private int portColor(String v, boolean current) {
		Updater.Entry e = Updater.entry(v);
		if (e.phase == 3 || e.check == Updater.Check.FAILED) return 0xFFFF6B6B;
		if (e.phase == 2) return 0xFF7CE38B;
		if (e.check == Updater.Check.READY) return current ? 0xFF8FB0FF : 0xFF7CE38B;
		return 0xFF8A8A94;
	}

	private static String modeName(VoiceConfig.Mode m) {
		switch (m) {
			case PTT: return "по зажатию кнопки";
			case VOICE: return "по голосу";
			default: return "всегда включён";
		}
	}

	private static String shortName(String s) {
		if (s == null || s.isEmpty()) return "по умолчанию";
		return s.length() > 26 ? s.substring(0, 25) + "…" : s;
	}

	private static String cycle(List<String> names, String cur) {
		int i = names.indexOf(cur);
		return names.get((i + 1) % names.size());
	}

	// ======================= виджеты =======================

	private abstract static class W {
		int x, y, w, h, ax, ay;
		boolean enabled = true, clickable = true;
		// кэш подписи
		int lrev = -1, ltw;
		String ltxt = "";

		boolean hit(int mx, int my) {
			return mx >= ax && mx < ax + w && my >= ay && my < ay + h;
		}

		void tick() {}

		abstract void draw(Gfx g, boolean hover, float dt);

		void down(int mx, int my) {}

		void drag(int mx, int my) {}

		void up() {}
	}

	private static final class Btn extends W {
		final Supplier<String> label;
		final Runnable action;
		BooleanSupplier warn, active;
		float hov, press = 0f, cHov = -1f, cPress = -1f;
		boolean pressed, cEn = true;
		int cFill, cLight, cBorder;

		Btn(Supplier<String> label, Runnable action) {
			this.label = label;
			this.action = action;
		}

		@Override
		void tick() {
			if (active != null) {
				boolean a = active.getAsBoolean();
				if (a != enabled) {
					enabled = a;
					invalidate();
				}
			}
		}

		@Override
		void down(int mx, int my) {
			pressed = true;
			action.run();
		}

		@Override
		void up() {
			pressed = false;
		}

		@Override
		void draw(Gfx g, boolean hover, float dt) {
			hov = Draw.approach(hov, hover ? 1f : 0f, dt, 18f);
			press = Draw.approach(press, pressed ? 1f : 0f, dt, 30f);
			if (hov != cHov || press != cPress || enabled != cEn) {
				cHov = hov;
				cPress = press;
				cEn = enabled;
				if (enabled) {
					cFill = Draw.lerp(Draw.lerp(0xFF2A2A2E, 0xFF3A3A40, hov), 0xFF1F1F23, press);
					cLight = Draw.lerp(0xFF45454C, 0xFF6A6A74, hov);
					cBorder = Draw.lerp(0xFF000000, 0xFF9FB4E8, hov * 0.8f);
				} else {
					cFill = 0xFF1C1C1F;
					cLight = 0xFF2A2A2E;
					cBorder = 0xFF000000;
				}
			}
			Draw.bevel(g, ax, ay, w, h, cFill, cLight, enabled ? 0xFF141416 : 0xFF101012, cBorder);
			if (lrev != RV) {
				ltxt = label.get();
				ltw = g.textWidth(ltxt);
				lrev = RV;
			}
			int col = !enabled ? 0xFF70707A : (warn != null && warn.getAsBoolean()) ? 0xFFFF6B6B : 0xFFE6E6EA;
			g.text(ltxt, ax + (w - ltw) / 2, ay + (h - 8) / 2 + (press > 0.5f ? 1 : 0), col);
		}
	}

	private static final class Tog extends W {
		final String text;
		final BooleanSupplier get;
		final Consumer<Boolean> set;
		float hov, on = -1f, cHov = -1f;
		int cFill, cLight, cBorder;

		Tog(String text, BooleanSupplier get, Consumer<Boolean> set) {
			this.text = text;
			this.get = get;
			this.set = set;
		}

		@Override
		void down(int mx, int my) {
			set.accept(!get.getAsBoolean());
		}

		@Override
		void draw(Gfx g, boolean hover, float dt) {
			hov = Draw.approach(hov, hover ? 1f : 0f, dt, 18f);
			float target = get.getAsBoolean() ? 1f : 0f;
			on = on < 0 ? target : Draw.approach(on, target, dt, 16f);
			if (hov != cHov) {
				cHov = hov;
				cFill = Draw.lerp(0xFF2A2A2E, 0xFF3A3A40, hov);
				cLight = Draw.lerp(0xFF45454C, 0xFF6A6A74, hov);
				cBorder = Draw.lerp(0xFF000000, 0xFF9FB4E8, hov * 0.8f);
			}
			Draw.bevel(g, ax, ay, w, h, cFill, cLight, 0xFF141416, cBorder);
			g.text(text, ax + 6, ay + (h - 8) / 2, 0xFFE6E6EA);
			int tx = ax + w - 32, ty = ay + 5;
			Draw.inset(g, tx, ty, 26, 10, Draw.lerp(0xFF111113, 0xFF2D7D4B, on));
			int kx = tx + 2 + Math.round(on * 14f);
			Draw.bevel(g, kx, ty + 1, 8, 8, 0xFF8C8C96, 0xFFC4C4CC, 0xFF55555C, 0xFF000000);
		}
	}

	private static final class Sld extends W {
		final double min, max;
		final DoubleSupplier get;
		final DoubleConsumer set;
		final DoubleFunction<String> label;
		float hov, disp = -1f, cHov = -1f;
		boolean drag;
		int cTrack, cBorder, cHandle;

		Sld(double min, double max, DoubleSupplier get, DoubleConsumer set, DoubleFunction<String> label) {
			this.min = min;
			this.max = max;
			this.get = get;
			this.set = set;
			this.label = label;
		}

		private void fromMouse(int mx) {
			double t = (mx - ax - 4) / (double) (w - 8);
			t = Math.max(0, Math.min(1, t));
			set.accept(min + t * (max - min));
		}

		@Override
		void down(int mx, int my) {
			drag = true;
			fromMouse(mx);
		}

		@Override
		void drag(int mx, int my) {
			if (drag) fromMouse(mx);
		}

		@Override
		void up() {
			drag = false;
		}

		@Override
		void draw(Gfx g, boolean hover, float dt) {
			hov = Draw.approach(hov, (hover || drag) ? 1f : 0f, dt, 18f);
			double val = get.getAsDouble();
			float target = (float) Math.max(0, Math.min(1, (val - min) / (max - min)));
			disp = disp < 0 ? target : Draw.approach(disp, target, dt, 24f);
			if (hov != cHov) {
				cHov = hov;
				cTrack = Draw.lerp(0xFF1B2A46, 0xFF28426F, hov);
				cBorder = Draw.lerp(0xFF000000, 0xFF9FB4E8, hov * 0.8f);
				cHandle = Draw.lerp(0xFF4A4A52, 0xFF6C6C78, hov);
			}
			Draw.inset(g, ax, ay, w, h, 0xFF101012);
			int fillW = Math.round((w - 4) * disp);
			if (fillW > 0) g.fill(ax + 2, ay + 2, ax + 2 + fillW, ay + h - 2, cTrack);
			int hx = ax + Math.round((w - 8) * disp);
			Draw.bevel(g, hx, ay, 8, h, cHandle, 0xFF8A8A96, 0xFF222226, cBorder);

			if (lrev != RV) {
				ltxt = label.apply(val);
				ltw = g.textWidth(ltxt);
				lrev = RV;
			}
			g.text(ltxt, ax + (w - ltw) / 2, ay + (h - 8) / 2, 0xFFEDEDF2);
		}
	}

	private static final class Txt extends W {
		final String[] lines;
		final int color;

		Txt(String[] lines, int color) {
			this.lines = lines;
			this.color = color;
			this.clickable = false;
		}

		@Override
		void draw(Gfx g, boolean hover, float dt) {
			for (int i = 0; i < lines.length; i++) g.text(lines[i], ax + 1, ay + i * 11 + 1, color);
		}
	}

	private static final class Meter extends W {
		float shown;

		Meter() {
			this.clickable = false;
		}

		@Override
		void draw(Gfx g, boolean hover, float dt) {
			float lvl = VoiceCore.level;
			shown = Draw.approach(shown, lvl, dt, lvl > shown ? 40f : 7f);
			Draw.inset(g, ax, ay, w, h, 0xFF0C0C0E);
			int inner = w - 4;
			int fill = Math.round(inner * shown);
			for (int x = 0; x < fill; x += 6) { // ~44 вместо ~130 вызовов
				g.fill(ax + 2 + x, ay + 2, ax + 2 + Math.min(x + 6, fill), ay + h - 2, Draw.levelColor(x / (float) inner));
			}
			int tx = ax + 2 + Math.round(inner * VoiceConfig.get().threshold);
			g.fill(tx, ay - 1, tx + 1, ay + h + 1, 0xFFFFFFFF);
		}
	}

	private static final class MicBtn extends W {
		float hov, on, cHov = -1f, cOn = -1f;
		int cFill, cLight, cBorder;

		@Override
		void down(int mx, int my) {
			VoiceCore.menuMic = !VoiceCore.menuMic;
		}

		@Override
		void draw(Gfx g, boolean hover, float dt) {
			hov = Draw.approach(hov, hover ? 1f : 0f, dt, 18f);
			on = Draw.approach(on, VoiceCore.menuMic ? 1f : 0f, dt, 14f);
			if (hov != cHov || on != cOn) {
				cHov = hov;
				cOn = on;
				cFill = Draw.lerp(Draw.lerp(0xFF2A2A2E, 0xFF3A3A40, hov), 0xFF24402F, on);
				cLight = Draw.lerp(0xFF45454C, 0xFF6A6A74, hov);
				cBorder = Draw.lerp(0xFF000000, 0xFF9FB4E8, hov * 0.8f);
			}
			Draw.bevel(g, ax, ay, w, h, cFill, cLight, 0xFF141416, cBorder);
			boolean isOn = VoiceCore.menuMic;
			Icons.mic(g, ax + 10, ay + 10, isOn ? 0xFF55FF55 : 0xFFAAAAAA, !isOn);
		}
	}

	/** Строка версии: номер и статус; кнопка установки добавляется отдельно. */
	private final class PortRow extends W {
		final String ver;
		final boolean current;
		String status = "";
		int color;
		int rev = -1;

		PortRow(String ver, boolean current) {
			this.ver = ver;
			this.current = current;
			this.clickable = false;
		}

		@Override
		void draw(Gfx g, boolean hover, float dt) {
			Draw.bevel(g, ax, ay, w, h, 0xFF1A1A1D, 0xFF2A2A2F, 0xFF101012, 0xFF000000);
			if (rev != RV) {
				status = portStatus(ver, current);
				color = portColor(ver, current);
				rev = RV;
			}
			g.text(ver, ax + 7, ay + 7, 0xFFFFFFFF);
			if (!status.isEmpty()) g.text(status, ax + 52, ay + 7, color);
		}
	}
}
