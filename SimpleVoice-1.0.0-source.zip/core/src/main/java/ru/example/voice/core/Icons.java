package ru.example.voice.core;

public final class Icons {
	private Icons() {}

	/** Иконка микрофона 13x14 с центром в (cx, cy); slashed = перечёркнута. */
	public static void mic(Gfx g, int cx, int cy, int c, boolean slashed) {
		g.fill(cx - 2, cy - 6, cx + 2, cy + 1, c);
		g.fill(cx - 4, cy - 2, cx - 3, cy + 3, c);
		g.fill(cx + 3, cy - 2, cx + 4, cy + 3, c);
		g.fill(cx - 3, cy + 3, cx + 3, cy + 4, c);
		g.fill(cx - 1, cy + 4, cx + 1, cy + 6, c);
		g.fill(cx - 3, cy + 6, cx + 3, cy + 7, c);
		if (slashed) {
			for (int t = 0; t <= 14; t++) {
				int x = cx - 6 + t * 12 / 14;
				int y = cy + 7 - t;
				g.fill(x, y, x + 2, y + 1, 0xFFFF5555);
			}
		}
	}
}
