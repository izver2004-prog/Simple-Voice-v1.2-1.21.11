package ru.example.voice.core;

/** Рисование в стиле Minecraft (фаски), но в тёмной палитре, и плавные анимации. */
public final class Draw {
	private Draw() {}

	/** Плавное приближение; у цели останавливается точно, чтобы кэш цветов не пересчитывался вечно. */
	public static float approach(float cur, float target, float dt, float rate) {
		if (cur == target) return cur;
		float n = cur + (target - cur) * (1f - (float) Math.exp(-rate * dt));
		return Math.abs(target - n) < 0.003f ? target : n;
	}

	private static final int[] LEVEL = new int[33];

	static {
		for (int i = 0; i < LEVEL.length; i++) LEVEL[i] = levelColorExact(i / 32f);
	}

	public static int lerp(int a, int b, float t) {
		if (t < 0f) t = 0f;
		if (t > 1f) t = 1f;
		int r = 0;
		for (int s = 24; s >= 0; s -= 8) {
			int ca = (a >>> s) & 0xFF, cb = (b >>> s) & 0xFF;
			r |= (Math.round(ca + (cb - ca) * t) & 0xFF) << s;
		}
		return r;
	}

	/** Кнопка/панель с фаской: светлый верх-лево, тёмный низ-право, чёрная рамка. */
	public static void bevel(Gfx g, int x, int y, int w, int h, int fill, int light, int dark, int border) {
		g.fill(x, y, x + w, y + h, border);
		g.fill(x + 1, y + 1, x + w - 1, y + h - 1, fill);
		g.fill(x + 1, y + 1, x + w - 1, y + 2, light);
		g.fill(x + 1, y + 1, x + 2, y + h - 1, light);
		g.fill(x + 1, y + h - 2, x + w - 1, y + h - 1, dark);
		g.fill(x + w - 2, y + 1, x + w - 1, y + h - 1, dark);
	}

	/** Вдавленная панель (дорожка слайдера, шкала). */
	public static void inset(Gfx g, int x, int y, int w, int h, int fill) {
		bevel(g, x, y, w, h, fill, 0xFF0A0A0B, 0xFF303036, 0xFF000000);
	}

	/** Зелёный -> жёлтый -> красный (из готовой таблицы). */
	public static int levelColor(float f) {
		int i = Math.round(f * 32f);
		return LEVEL[i < 0 ? 0 : Math.min(i, 32)];
	}

	private static int levelColorExact(float f) {
		int green = 0xFF4CD964, yellow = 0xFFF5D142, red = 0xFFFF4D4D;
		if (f < 0.6f) return lerp(green, yellow, f / 0.6f);
		return lerp(yellow, red, (f - 0.6f) / 0.4f);
	}

	public static void centered(Gfx g, String s, int cx, int y, int color) {
		g.text(s, cx - g.textWidth(s) / 2, y, color);
	}
}
